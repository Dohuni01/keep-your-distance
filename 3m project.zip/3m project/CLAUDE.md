# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

UWB Phase 1 - Worker proximity safety system for construction equipment (excavator).
**5 devices**: 1 equipment node (ESP32 + DW3000 UWB) + 4 worker tags.
The relay on the equipment node cuts power to dangerous machinery when a worker is within 3m.

## Key Files

| File | Role |
|------|------|
| `uwb_phase1_starter/equipment_node/equipment_node.ino` | Main firmware — state machine, relay control, JSON logging |
| `uwb_phase1_starter/worker_tag/worker_tag_responder_template.ino` | Template skeleton; fill in with the board vendor's DS-TWR responder example |
| `uwb_phase1_starter/tools/server_log.py` | PC-side HTTP server that receives JSON POST events and writes to CSV |

## Flashing & Running

This is Arduino firmware for **ESP32 + DW3000**. Use Arduino IDE or `arduino-cli`.

**Flash equipment node:**
```
arduino-cli compile --fqbn esp32:esp32:esp32 equipment_node/equipment_node.ino
arduino-cli upload  --fqbn esp32:esp32:esp32 -p COM<N> equipment_node/equipment_node.ino
```

**Open Serial Monitor (115200 baud)** — the firmware prints JSON lines for every state transition and a heartbeat every second.

**Run the logging server (optional):**
```
python tools/server_log.py --host 0.0.0.0 --port 8000
```
Set `USE_WIFI_POST 1` and `SERVER_URL` in the `.ino` before flashing to send events to this server. Events are appended to `uwb_events.csv`.

## Testing Without Hardware

Set `USE_FAKE_SERIAL_RANGES 1` (default). Type into Serial Monitor:
```
1001 2.80    → DANGER_ENTER, relay ON
1001 3.20    → DANGER_HOLD, relay stays ON  (hysteresis zone 3.0–3.5 m)
1001 3.80    → need 3 consecutive to exit danger
1001 NR      → No Range — treated as FAULT if last distance was near danger
```
Tag IDs are decimal hex: `1001` = `0x1001`.

## Architecture: Danger State Machine

All logic lives in `equipment_node.ino`. The DW3000 ranging API is intentionally isolated to two hook functions:

- `onUwbRange(tagId, distanceM, rssi)` — called when a valid ranging result is received
- `onUwbNoRange(tagId)` — called when a poll times out

**State transitions per `TagState`:**
- `distance <= 3.0 m` → `dangerLatched = true`, relay ON immediately
- `3.0 m < distance < 3.5 m` → hysteresis zone, previous state held
- `distance >= 3.5 m` → increments `safeCount`; relay OFF only after **3 consecutive** safe samples
- No Range while last distance was `< 3.5 m` → `fault = true`; relay stays ON (`RELAY_ON_WHILE_FAULT = true`)
- Tag silent > 5 s → `TAG_STALE` event emitted

**System relay** = OR of all 4 tag relay requirements. Any one tag in DANGER/FAULT keeps relay ON.

## Key Configuration Constants (equipment_node.ino)

| Constant | Default | Meaning |
|----------|---------|---------|
| `DANGER_ON_M` | 3.00 | Distance threshold to latch danger |
| `DANGER_OFF_M` | 3.50 | Threshold required for safe candidate |
| `SAFE_SAMPLE_COUNT_TO_OFF` | 3 | Consecutive safe samples to release relay |
| `NO_RANGE_HOLD_MS` | 1500 | Time before No Range becomes a fault |
| `TAG_STALE_MS` | 5000 | Silence timeout before STALE event |
| `RELAY_ACTIVE_LOW` | false | Set true for active-low relay boards |
| `RELAY_PIN` | 26 | Adjust to your ESP32 board layout |

## Integrating Real DW3000 Ranging

1. Set `USE_FAKE_SERIAL_RANGES 0`.
2. In `setupUwbReal()`: initialize SPI + DW3000 as DS-TWR **initiator**, own address `0xE001`.
3. In `pollUwbReal()`: poll `TAG_IDS[]` sequentially (one per 80–150 ms to avoid collision).
4. In the ranging callback: call `onUwbRange(targetId, distanceMeters, rssi)`.
5. In the timeout callback: call `onUwbNoRange(targetId)`.

Worker tags use `worker_tag_responder_template.ino` — replace setup/loop with the board vendor's DS-TWR responder, set each tag's short address (`0x1001`–`0x1004`), and network ID `0xBEEF`.

## JSON Event Schema (Serial / HTTP POST)

Every state change emits:
```json
{"equipmentId":"EXC-001","tagId":"1001","event":"DANGER_ENTER","seq":5,
 "distanceM":2.800,"danger":true,"relay":true,"noRange":false,"fault":false,
 "zone":"DANGER","rssi":-72,"uptimeMs":12345}
```
Heartbeat (`HEARTBEAT`) also includes a `"tags":[]` array of all tag summaries.

## Test Plan Phases

See `TEST_PLAN.md` for the full acceptance criteria:
- **Phase A**: State machine via fake serial (no hardware)
- **Phase B**: 1 equipment + 1 worker tag, 100 samples per distance
- **Phase C**: Bias calibration / lookup table
- **Phase D**: Multi-tag polling, all 4 tags
- **Phase E**: Field/noise tests (body occlusion, metal, antenna orientation)
