# UWB + GPS 실시간 위치 추적 대시보드 구현 계획

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 굴착기에 부착된 UWB 앵커 3개(GPS 포함)와 작업자 태그 2개를 연결하여, 작업자 위치를 위성 지도 이미지 위에 실시간 표시하고 3m 이내 진입 시 릴레이를 즉시 작동시킨다.

**Architecture:** 앵커 펌웨어가 GPS 위치 + UWB 거리를 WiFi HTTP POST로 Python 서버에 전송한다. 서버는 삼변측량으로 태그 위치를 계산하고 SSE로 브라우저에 push한다. 3m 릴레이는 앵커 로컬에서 서버 없이 즉시 판단한다. TDMA 슬롯 방식으로 태그 수 증가 시 펌웨어 수정 없이 확장 가능하다.

**Tech Stack:** Arduino C++ (ESP32 + DW3000 + TinyGPS++), Python 3 (Flask, NumPy), HTML/JS (Vanilla, Canvas API, SSE)

---

## 파일 구조

```
uwb_phase1_starter/
  anchor_node/
    anchor_node.ino          ← 신규: 앵커 펌웨어 (GPS + TDMA + 안전 로직 + WiFi POST)
  tag_node/
    tag_node.ino             ← 신규: 태그 펌웨어 (TDMA 슬롯 응답)
  tools/
    requirements.txt         ← 신규: Flask, NumPy
    trilateration.py         ← 신규: 삼변측량 알고리즘
    gps_utils.py             ← 신규: GPS ↔ 로컬XY ↔ 픽셀 변환
    server.py                ← 신규: Flask 서버 (server_log.py 대체)
    static/
      index.html             ← 신규: 대시보드 HTML
      dashboard.js           ← 신규: 지도 + 실시간 마커 JS
  tests/
    test_trilateration.py    ← 신규
    test_gps_utils.py        ← 신규
```

**JSON 계약 (앵커 → 서버 POST /range):**
```json
{
  "anchorId": "ANC-001",
  "lat": 37.5034,
  "lon": 127.0234,
  "tagId": "1001",
  "distanceM": 2.75,
  "danger": true,
  "relay": true,
  "zone": "DANGER",
  "noRange": false,
  "fault": false,
  "seq": 42,
  "uptimeMs": 12345
}
```

**SSE 이벤트 형식 (서버 → 브라우저):**
```json
{
  "type": "position_update",
  "tagId": "1001",
  "lat": 37.5031,
  "lon": 127.0237,
  "zone": "DANGER",
  "distanceM": 2.75,
  "relay": true,
  "anchors": [
    {"anchorId": "ANC-001", "lat": 37.5034, "lon": 127.0234}
  ]
}
```

---

## Task 1: requirements.txt 및 프로젝트 구조 생성

**Files:**
- Create: `uwb_phase1_starter/tools/requirements.txt`
- Create: `uwb_phase1_starter/tools/static/` (디렉터리)
- Create: `uwb_phase1_starter/tests/` (디렉터리)

- [ ] **Step 1: requirements.txt 작성**

```
# uwb_phase1_starter/tools/requirements.txt
flask==3.0.3
numpy==1.26.4
```

- [ ] **Step 2: 디렉터리 생성 (PowerShell)**

```powershell
cd "C:\Users\김도훈\Desktop\3m project\uwb_phase1_starter"
New-Item -ItemType Directory -Force tools\static
New-Item -ItemType Directory -Force tests
```

- [ ] **Step 3: 패키지 설치**

```powershell
pip install -r tools\requirements.txt
```

Expected output: `Successfully installed flask-3.0.3 numpy-1.26.4 ...`

- [ ] **Step 4: 빈 테스트 파일 생성**

```powershell
type nul > tests\test_trilateration.py
type nul > tests\test_gps_utils.py
```

- [ ] **Step 5: 커밋**

```powershell
git add tools\requirements.txt tests\
git commit -m "chore: add requirements and test structure for positioning system"
```

---

## Task 2: 삼변측량 모듈 (trilateration.py)

**Files:**
- Create: `uwb_phase1_starter/tools/trilateration.py`
- Modify: `uwb_phase1_starter/tests/test_trilateration.py`

- [ ] **Step 1: 실패 테스트 작성**

`uwb_phase1_starter/tests/test_trilateration.py`:
```python
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))
from trilateration import trilaterate
import math

def test_basic_trilateration():
    # 앵커: (0,0), (10,0), (0,10) / 태그: (3,4)
    # d1=5, d2=sqrt(65)≈8.06, d3=sqrt(45)≈6.71
    anchors = [(0.0, 0.0), (10.0, 0.0), (0.0, 10.0)]
    distances = [5.0, math.sqrt(65), math.sqrt(45)]
    result = trilaterate(anchors, distances)
    assert result is not None
    x, y = result
    assert abs(x - 3.0) < 0.01
    assert abs(y - 4.0) < 0.01

def test_trilaterate_returns_none_with_two_anchors():
    anchors = [(0.0, 0.0), (10.0, 0.0)]
    distances = [5.0, 8.06]
    result = trilaterate(anchors, distances)
    assert result is None

def test_trilaterate_with_noise():
    # 거리에 10cm 오차 추가
    anchors = [(0.0, 0.0), (10.0, 0.0), (0.0, 10.0)]
    distances = [5.1, math.sqrt(65) - 0.1, math.sqrt(45) + 0.05]
    result = trilaterate(anchors, distances)
    assert result is not None
    x, y = result
    assert abs(x - 3.0) < 0.5
    assert abs(y - 4.0) < 0.5
```

- [ ] **Step 2: 테스트 실행 — 실패 확인**

```powershell
cd "C:\Users\김도훈\Desktop\3m project\uwb_phase1_starter"
python -m pytest tests\test_trilateration.py -v
```

Expected: `ModuleNotFoundError: No module named 'trilateration'`

- [ ] **Step 3: trilateration.py 구현**

`uwb_phase1_starter/tools/trilateration.py`:
```python
import numpy as np

def trilaterate(anchors, distances):
    """
    anchors:   list of (x, y) 로컬 좌표 (미터)
    distances: list of float 거리 (미터), anchors와 같은 순서
    returns:   (x, y) 또는 앵커가 2개 미만이면 None
    """
    if len(anchors) < 3 or len(distances) < 3:
        return None

    x1, y1 = anchors[0]
    d1 = distances[0]

    rows_A = []
    rows_b = []
    for i in range(1, len(anchors)):
        xi, yi = anchors[i]
        di = distances[i]
        rows_A.append([2 * (xi - x1), 2 * (yi - y1)])
        rows_b.append(
            d1**2 - di**2
            + xi**2 - x1**2
            + yi**2 - y1**2
        )

    A = np.array(rows_A, dtype=float)
    b = np.array(rows_b, dtype=float)

    try:
        result, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        return float(result[0]), float(result[1])
    except np.linalg.LinAlgError:
        return None
```

- [ ] **Step 4: 테스트 실행 — 통과 확인**

```powershell
python -m pytest tests\test_trilateration.py -v
```

Expected:
```
PASSED tests/test_trilateration.py::test_basic_trilateration
PASSED tests/test_trilateration.py::test_trilaterate_returns_none_with_two_anchors
PASSED tests/test_trilateration.py::test_trilaterate_with_noise
```

- [ ] **Step 5: 커밋**

```powershell
git add tools\trilateration.py tests\test_trilateration.py
git commit -m "feat: add trilateration module with tests"
```

---

## Task 3: GPS 유틸리티 모듈 (gps_utils.py)

**Files:**
- Create: `uwb_phase1_starter/tools/gps_utils.py`
- Modify: `uwb_phase1_starter/tests/test_gps_utils.py`

- [ ] **Step 1: 실패 테스트 작성**

`uwb_phase1_starter/tests/test_gps_utils.py`:
```python
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))
from gps_utils import latlon_to_xy, xy_to_latlon, latlon_to_pixel
import math

ORIGIN_LAT = 37.5000
ORIGIN_LON = 127.0000

def test_latlon_to_xy_north():
    # 0.0009도 북쪽 ≈ 100.2m
    x, y = latlon_to_xy(37.5009, 127.0000, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x) < 1.0          # 동서 이동 없음
    assert abs(y - 100.19) < 1.0  # 북쪽 약 100m

def test_latlon_to_xy_east():
    # 0.0009도 동쪽, 위도 37.5° 기준
    x, y = latlon_to_xy(37.5000, 127.0009, ORIGIN_LAT, ORIGIN_LON)
    assert abs(y) < 1.0           # 남북 이동 없음
    assert abs(x - 79.5) < 2.0   # 동쪽 약 79.5m

def test_xy_to_latlon_roundtrip():
    lat, lon = xy_to_latlon(50.0, 80.0, ORIGIN_LAT, ORIGIN_LON)
    x, y = latlon_to_xy(lat, lon, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x - 50.0) < 0.01
    assert abs(y - 80.0) < 0.01

def test_latlon_to_pixel_center():
    bounds = {
        'top_left':  (37.5010, 127.0000),
        'bot_right': (37.4990, 127.0020),
    }
    # 중앙점 → 픽셀 중앙
    px, py = latlon_to_pixel(37.5000, 127.0010, bounds, 1000, 800)
    assert abs(px - 500) < 1
    assert abs(py - 400) < 1

def test_latlon_to_pixel_top_left():
    bounds = {
        'top_left':  (37.5010, 127.0000),
        'bot_right': (37.4990, 127.0020),
    }
    px, py = latlon_to_pixel(37.5010, 127.0000, bounds, 1000, 800)
    assert abs(px) < 1
    assert abs(py) < 1
```

- [ ] **Step 2: 테스트 실행 — 실패 확인**

```powershell
python -m pytest tests\test_gps_utils.py -v
```

Expected: `ModuleNotFoundError: No module named 'gps_utils'`

- [ ] **Step 3: gps_utils.py 구현**

`uwb_phase1_starter/tools/gps_utils.py`:
```python
import math

METERS_PER_DEGREE_LAT = 111320.0  # 위도 1도 ≈ 111.32 km


def latlon_to_xy(lat, lon, origin_lat, origin_lon):
    """
    GPS 좌표를 origin 기준 로컬 XY (미터)로 변환.
    x: 동쪽(+), y: 북쪽(+)
    """
    cos_lat = math.cos(math.radians(origin_lat))
    dx = (lon - origin_lon) * cos_lat * METERS_PER_DEGREE_LAT
    dy = (lat - origin_lat) * METERS_PER_DEGREE_LAT
    return dx, dy


def xy_to_latlon(x, y, origin_lat, origin_lon):
    """로컬 XY (미터)를 GPS 좌표로 역변환."""
    cos_lat = math.cos(math.radians(origin_lat))
    lat = origin_lat + y / METERS_PER_DEGREE_LAT
    lon = origin_lon + x / (cos_lat * METERS_PER_DEGREE_LAT)
    return lat, lon


def latlon_to_pixel(lat, lon, bounds, img_width, img_height):
    """
    GPS 좌표를 지도 이미지 픽셀 좌표로 변환.
    bounds = {'top_left': (lat0, lon0), 'bot_right': (lat1, lon1)}
    """
    lat0, lon0 = bounds['top_left']
    lat1, lon1 = bounds['bot_right']
    px = (lon - lon0) / (lon1 - lon0) * img_width
    py = (lat0 - lat) / (lat0 - lat1) * img_height
    return px, py
```

- [ ] **Step 4: 테스트 실행 — 통과 확인**

```powershell
python -m pytest tests\test_gps_utils.py -v
```

Expected: 5 PASSED

- [ ] **Step 5: 커밋**

```powershell
git add tools\gps_utils.py tests\test_gps_utils.py
git commit -m "feat: add GPS coordinate utility module with tests"
```

---

## Task 4: Flask 서버 (server.py)

**Files:**
- Create: `uwb_phase1_starter/tools/server.py`

- [ ] **Step 1: server.py 작성**

`uwb_phase1_starter/tools/server.py`:
```python
#!/usr/bin/env python3
"""
UWB + GPS 실시간 위치 추적 서버.
실행: python tools/server.py
"""
import json
import threading
import time
from datetime import datetime
from pathlib import Path
from queue import Empty, Queue

from flask import Flask, Response, jsonify, request, send_from_directory

from gps_utils import latlon_to_pixel, latlon_to_xy, xy_to_latlon
from trilateration import trilaterate

app = Flask(__name__, static_folder="static")

# --- 공유 상태 (lock으로 보호) ---
lock = threading.Lock()

# anchor_state[anchorId] = {"lat": float, "lon": float, "tags": {tagId: {"distanceM": float, "ts": float}}}
anchor_state = {}

# tag_state[tagId] = {"lat": float, "lon": float, "zone": str, "distanceM": float, "relay": bool}
tag_state = {}

# 지도 설정
map_config = {
    "bounds": None,   # {"top_left": [lat, lon], "bot_right": [lat, lon]}
    "img_name": None, # 업로드된 이미지 파일명
    "img_width": 0,
    "img_height": 0,
}

# SSE 구독자
sse_clients = []

STATIC_DIR = Path(__file__).parent / "static"
STALE_ANCHOR_SEC = 5.0   # 이 시간 이상 거리 정보 없으면 태그 위치 계산 제외


def push_event(data):
    """모든 SSE 구독자에게 이벤트 전송."""
    with lock:
        for q in sse_clients:
            q.put(data)


def recompute_tag_position(tag_id):
    """
    현재 anchor_state에서 tag_id에 대한 삼변측량을 수행.
    map_config.bounds가 설정된 경우에만 위도/경도 → 픽셀 변환 포함.
    결과를 tag_state에 저장하고 SSE 이벤트를 push.
    """
    now = time.time()
    anchors_xy = []
    distances = []
    anchor_info = []
    origin = None  # 첫 번째 앵커를 로컬 좌표 원점으로 사용

    with lock:
        for anchor_id, a in anchor_state.items():
            if tag_id not in a["tags"]:
                continue
            entry = a["tags"][tag_id]
            if now - entry["ts"] > STALE_ANCHOR_SEC:
                continue
            if origin is None:
                origin = (a["lat"], a["lon"])
            x, y = latlon_to_xy(a["lat"], a["lon"], origin[0], origin[1])
            anchors_xy.append((x, y))
            distances.append(entry["distanceM"])
            anchor_info.append({"anchorId": anchor_id, "lat": a["lat"], "lon": a["lon"]})

        if len(anchors_xy) < 3:
            return  # 앵커 3개 미만 → 위치 계산 불가

        result_xy = trilaterate(anchors_xy, distances)
        if result_xy is None:
            return

        tag_lat, tag_lon = xy_to_latlon(result_xy[0], result_xy[1], origin[0], origin[1])

        # 가장 가까운 앵커 기준 zone/danger 정보 가져오기 (첫 번째 앵커 사용)
        first_anchor_id = list(anchor_state.keys())[0]
        entry = anchor_state[first_anchor_id]["tags"].get(tag_id, {})
        zone = entry.get("zone", "UNKNOWN")
        distance_m = entry.get("distanceM", -1)
        relay = entry.get("relay", False)

        tag_state[tag_id] = {
            "lat": tag_lat,
            "lon": tag_lon,
            "zone": zone,
            "distanceM": distance_m,
            "relay": relay,
        }

        px, py = None, None
        cfg = map_config
        if cfg["bounds"] and cfg["img_width"]:
            px, py = latlon_to_pixel(
                tag_lat, tag_lon, cfg["bounds"], cfg["img_width"], cfg["img_height"]
            )

    push_event({
        "type": "position_update",
        "tagId": tag_id,
        "lat": tag_lat,
        "lon": tag_lon,
        "px": px,
        "py": py,
        "zone": zone,
        "distanceM": distance_m,
        "relay": relay,
        "anchors": anchor_info,
        "ts": datetime.now().isoformat(timespec="milliseconds"),
    })


# --- 엔드포인트 ---

@app.post("/range")
def receive_range():
    """앵커에서 GPS + UWB 거리 수신."""
    data = request.get_json(silent=True)
    if not data:
        return "BAD_JSON", 400

    anchor_id = data.get("anchorId")
    tag_id = data.get("tagId")
    lat = data.get("lat")
    lon = data.get("lon")
    distance_m = data.get("distanceM")

    if None in (anchor_id, tag_id, lat, lon, distance_m):
        return "MISSING_FIELD", 400

    with lock:
        if anchor_id not in anchor_state:
            anchor_state[anchor_id] = {"lat": lat, "lon": lon, "tags": {}}
        anchor_state[anchor_id]["lat"] = lat
        anchor_state[anchor_id]["lon"] = lon
        anchor_state[anchor_id]["tags"][tag_id] = {
            "distanceM": distance_m,
            "zone": data.get("zone", "UNKNOWN"),
            "relay": data.get("relay", False),
            "ts": time.time(),
        }

    recompute_tag_position(tag_id)
    return "OK", 200


@app.get("/events")
def sse_stream():
    """SSE 스트림 — 브라우저가 구독."""
    def generate():
        q = Queue()
        with lock:
            sse_clients.append(q)
        try:
            # 연결 즉시 현재 상태 전송
            with lock:
                snapshot = dict(tag_state)
            for tid, ts in snapshot.items():
                yield f"data: {json.dumps({**ts, 'type': 'position_update', 'tagId': tid})}\n\n"

            while True:
                try:
                    msg = q.get(timeout=25)
                    yield f"data: {json.dumps(msg)}\n\n"
                except Empty:
                    yield ": keepalive\n\n"  # 연결 유지
        finally:
            with lock:
                if q in sse_clients:
                    sse_clients.remove(q)

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/config/bounds")
def set_bounds():
    """지도 GPS 바운드 설정. body: {top_left:[lat,lon], bot_right:[lat,lon], img_width:int, img_height:int}"""
    data = request.get_json(silent=True)
    if not data:
        return "BAD_JSON", 400
    with lock:
        map_config["bounds"] = {
            "top_left": data["top_left"],
            "bot_right": data["bot_right"],
        }
        map_config["img_width"] = int(data.get("img_width", 0))
        map_config["img_height"] = int(data.get("img_height", 0))
    return jsonify({"status": "ok", "bounds": map_config["bounds"]})


@app.get("/config")
def get_config():
    with lock:
        return jsonify(map_config)


@app.get("/state")
def get_state():
    """현재 앵커/태그 상태 스냅샷 (디버깅용)."""
    with lock:
        return jsonify({"anchors": anchor_state, "tags": tag_state})


@app.get("/")
def dashboard():
    return send_from_directory(STATIC_DIR, "index.html")


@app.get("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(STATIC_DIR, filename)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    print(f"서버 시작: http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, threaded=True)
```

- [ ] **Step 2: 서버 기동 확인**

```powershell
cd "C:\Users\김도훈\Desktop\3m project\uwb_phase1_starter"
python tools\server.py
```

Expected: `서버 시작: http://0.0.0.0:8000`

- [ ] **Step 3: /range 엔드포인트 수동 테스트 (새 터미널)**

```powershell
# 앵커 3개 거리 데이터 전송
$body1 = '{"anchorId":"ANC-001","lat":37.5034,"lon":127.0234,"tagId":"1001","distanceM":2.75,"zone":"DANGER","relay":true}'
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $body1

$body2 = '{"anchorId":"ANC-002","lat":37.5036,"lon":127.0240,"tagId":"1001","distanceM":3.80,"zone":"SAFE","relay":false}'
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $body2

$body3 = '{"anchorId":"ANC-003","lat":37.5030,"lon":127.0238,"tagId":"1001","distanceM":4.10,"zone":"SAFE","relay":false}'
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $body3

# 상태 확인
Invoke-WebRequest -Uri http://localhost:8000/state | Select-Object -ExpandProperty Content
```

Expected: `{"anchors":{...},"tags":{"1001":{"lat":...,"lon":...,"zone":"DANGER",...}}}`

- [ ] **Step 4: 커밋**

```powershell
git add tools\server.py
git commit -m "feat: add Flask server with trilateration, SSE, and config endpoints"
```

---

## Task 5: 브라우저 대시보드

**Files:**
- Create: `uwb_phase1_starter/tools/static/index.html`
- Create: `uwb_phase1_starter/tools/static/dashboard.js`

- [ ] **Step 1: index.html 작성**

`uwb_phase1_starter/tools/static/index.html`:
```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>UWB 안전 대시보드</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #111; color: #eee; font-family: monospace; display: flex; flex-direction: column; height: 100vh; }

    #topbar {
      display: flex; align-items: center; gap: 12px;
      padding: 8px 14px; background: #1a1a2e; border-bottom: 1px solid #333; flex-shrink: 0;
    }
    #relay-badge {
      padding: 4px 10px; border-radius: 4px; font-weight: bold; font-size: 13px;
      background: #2ecc71; color: #000; transition: background 0.2s;
    }
    #relay-badge.danger { background: #e74c3c; color: #fff; }
    #server-status { font-size: 11px; color: #888; margin-left: auto; }

    #main { display: flex; flex: 1; overflow: hidden; }

    #map-container {
      flex: 1; position: relative; overflow: hidden; background: #222;
    }
    #map-canvas { position: absolute; top: 0; left: 0; }

    #sidebar {
      width: 220px; background: #1a1a2e; border-left: 1px solid #333;
      display: flex; flex-direction: column; overflow-y: auto; flex-shrink: 0;
    }
    .sidebar-section { padding: 10px; border-bottom: 1px solid #2a2a3e; }
    .sidebar-section h3 { font-size: 11px; color: #888; margin-bottom: 6px; letter-spacing: 1px; }

    .tag-card {
      background: #12121f; border-radius: 4px; padding: 8px; margin-bottom: 6px;
      border-left: 3px solid #555;
    }
    .tag-card.DANGER  { border-color: #e74c3c; }
    .tag-card.WARNING { border-color: #f39c12; }
    .tag-card.SAFE    { border-color: #2ecc71; }
    .tag-card .tag-id   { font-size: 12px; font-weight: bold; }
    .tag-card .tag-dist { font-size: 11px; color: #aaa; }
    .tag-card .tag-zone { font-size: 10px; margin-top: 2px; }
    .tag-card.DANGER  .tag-zone { color: #e74c3c; }
    .tag-card.WARNING .tag-zone { color: #f39c12; }
    .tag-card.SAFE    .tag-zone { color: #2ecc71; }

    #config-form input[type=text], #config-form input[type=number] {
      width: 100%; background: #0d1117; border: 1px solid #333; color: #eee;
      padding: 4px 6px; border-radius: 3px; font-size: 11px; margin-bottom: 4px;
    }
    #config-form label { font-size: 10px; color: #888; display: block; margin-bottom: 2px; }
    #config-form button {
      width: 100%; background: #3498db; color: #fff; border: none;
      padding: 5px; border-radius: 3px; cursor: pointer; font-size: 11px;
    }
    #map-upload { width: 100%; margin-bottom: 6px; font-size: 11px; }

    #log { flex: 1; overflow-y: auto; padding: 8px; font-size: 10px; color: #666; }
    #log .log-entry { margin-bottom: 2px; }
    #log .log-entry.danger { color: #e74c3c; }
  </style>
</head>
<body>
  <div id="topbar">
    <span style="font-weight:bold;font-size:14px;">UWB 안전 대시보드</span>
    <div id="relay-badge">RELAY OFF</div>
    <span id="server-status">서버 연결 중...</span>
  </div>

  <div id="main">
    <div id="map-container">
      <canvas id="map-canvas"></canvas>
    </div>

    <div id="sidebar">
      <div class="sidebar-section">
        <h3>태그 상태</h3>
        <div id="tag-list"></div>
      </div>

      <div class="sidebar-section">
        <h3>지도 설정</h3>
        <div id="config-form">
          <label>지도 이미지</label>
          <input type="file" id="map-upload" accept="image/*">

          <label>좌상단 위도</label>
          <input type="text" id="tl-lat" placeholder="37.5040">
          <label>좌상단 경도</label>
          <input type="text" id="tl-lon" placeholder="127.0228">
          <label>우하단 위도</label>
          <input type="text" id="br-lat" placeholder="37.5028">
          <label>우하단 경도</label>
          <input type="text" id="br-lon" placeholder="127.0242">

          <button onclick="applyConfig()">적용</button>
        </div>
      </div>

      <div class="sidebar-section" style="flex:1;display:flex;flex-direction:column;min-height:0;">
        <h3>이벤트 로그</h3>
        <div id="log"></div>
      </div>
    </div>
  </div>

  <script src="dashboard.js"></script>
</body>
</html>
```

- [ ] **Step 2: dashboard.js 작성**

`uwb_phase1_starter/tools/static/dashboard.js`:
```javascript
// --- 상태 ---
const tagStates = {};    // tagId → {lat, lon, px, py, zone, distanceM, relay}
const anchorStates = {}; // anchorId → {lat, lon, px, py}
let mapImage = null;
let mapBounds = null;    // {top_left:[lat,lon], bot_right:[lat,lon]}
let imgW = 0, imgH = 0;

const DANGER_RADIUS_M = 3.0;
const TAG_COLORS = ['#e74c3c', '#f39c12', '#9b59b6', '#1abc9c', '#e67e22'];

// --- 캔버스 ---
const container = document.getElementById('map-container');
const canvas    = document.getElementById('map-canvas');
const ctx       = canvas.getContext('2d');

function resizeCanvas() {
  canvas.width  = container.clientWidth;
  canvas.height = container.clientHeight;
  redraw();
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// --- GPS ↔ 픽셀 변환 ---
function latlonToPixel(lat, lon) {
  if (!mapBounds || !imgW) return null;
  const [lat0, lon0] = mapBounds.top_left;
  const [lat1, lon1] = mapBounds.bot_right;
  // 지도 이미지가 캔버스에 맞게 렌더링된 스케일 반영
  const scaleX = canvas.width  / imgW;
  const scaleY = canvas.height / imgH;
  const scale  = Math.min(scaleX, scaleY);
  const offX   = (canvas.width  - imgW * scale) / 2;
  const offY   = (canvas.height - imgH * scale) / 2;
  const px = (lon - lon0) / (lon1 - lon0) * imgW * scale + offX;
  const py = (lat0 - lat) / (lat0 - lat1) * imgH * scale + offY;
  return { x: px, y: py };
}

// 미터 → 픽셀 변환 (위도 기준 근사)
function metersToPixels(meters) {
  if (!mapBounds || !imgW) return 0;
  const [lat0, lon0] = mapBounds.top_left;
  const [lat1, lon1] = mapBounds.bot_right;
  const scaleX = canvas.width  / imgW;
  const scaleY = canvas.height / imgH;
  const scale  = Math.min(scaleX, scaleY);
  const latSpanM  = Math.abs(lat0 - lat1) * 111320;
  const pixPerMeter = imgH * scale / latSpanM;
  return meters * pixPerMeter;
}

// --- 그리기 ---
function redraw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (mapImage) {
    const scaleX = canvas.width  / imgW;
    const scaleY = canvas.height / imgH;
    const scale  = Math.min(scaleX, scaleY);
    const offX   = (canvas.width  - imgW * scale) / 2;
    const offY   = (canvas.height - imgH * scale) / 2;
    ctx.drawImage(mapImage, offX, offY, imgW * scale, imgH * scale);
  } else {
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#555';
    ctx.font = '14px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('지도 이미지를 설정 패널에서 업로드하세요', canvas.width / 2, canvas.height / 2);
    ctx.textAlign = 'left';
  }

  // 앵커 그리기 (파란 사각형)
  Object.values(anchorStates).forEach(a => {
    const pos = latlonToPixel(a.lat, a.lon);
    if (!pos) return;
    // 3m 위험 반경 원
    const r = metersToPixels(DANGER_RADIUS_M);
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, r, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(231,76,60,0.35)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 4]);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(231,76,60,0.07)';
    ctx.fill();

    // 앵커 마커
    ctx.fillStyle = '#3498db';
    ctx.fillRect(pos.x - 7, pos.y - 7, 14, 14);
    ctx.strokeStyle = '#5dade2';
    ctx.lineWidth = 2;
    ctx.strokeRect(pos.x - 7, pos.y - 7, 14, 14);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 8px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(a.anchorId ? a.anchorId.slice(-3) : 'A', pos.x, pos.y + 3);
    ctx.textAlign = 'left';
  });

  // 태그 그리기 (색깔 원)
  let colorIdx = 0;
  Object.entries(tagStates).forEach(([tagId, t]) => {
    const pos = latlonToPixel(t.lat, t.lon);
    if (!pos) return;
    const color = TAG_COLORS[colorIdx++ % TAG_COLORS.length];
    const isD   = t.zone === 'DANGER';

    if (isD) {
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 18, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(231,76,60,0.25)';
      ctx.fill();
    }

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 9, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth   = isD ? 2.5 : 1.5;
    ctx.stroke();

    ctx.fillStyle = '#fff';
    ctx.font      = 'bold 8px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(tagId.slice(-3), pos.x, pos.y + 3);

    ctx.fillStyle = color;
    ctx.font      = '9px monospace';
    ctx.fillText(`${(t.distanceM || 0).toFixed(1)}m`, pos.x + 12, pos.y - 6);
    ctx.textAlign = 'left';
  });
}

// --- SSE 연결 ---
function connectSSE() {
  const es = new EventSource('/events');
  es.onopen = () => {
    document.getElementById('server-status').textContent = '● 연결됨';
  };
  es.onerror = () => {
    document.getElementById('server-status').textContent = '○ 연결 끊김 — 재연결 중';
  };
  es.onmessage = e => {
    const data = JSON.parse(e.data);
    if (data.type === 'position_update') {
      tagStates[data.tagId] = data;
      // 앵커 위치 갱신
      (data.anchors || []).forEach(a => { anchorStates[a.anchorId] = a; });
      updateSidebar();
      redraw();
      addLog(data);
    }
  };
}

function updateSidebar() {
  const list = document.getElementById('tag-list');
  list.innerHTML = '';
  let anyDanger = false;
  Object.entries(tagStates).forEach(([tagId, t]) => {
    if (t.zone === 'DANGER' || t.relay) anyDanger = true;
    list.innerHTML += `
      <div class="tag-card ${t.zone}">
        <div class="tag-id">TAG-${tagId}</div>
        <div class="tag-dist">${(t.distanceM || 0).toFixed(2)} m</div>
        <div class="tag-zone">${t.zone}</div>
      </div>`;
  });
  const badge = document.getElementById('relay-badge');
  badge.textContent = anyDanger ? '⚠ RELAY ON' : 'RELAY OFF';
  badge.className   = anyDanger ? 'danger' : '';
}

function addLog(data) {
  const log = document.getElementById('log');
  const div = document.createElement('div');
  div.className = `log-entry ${data.zone === 'DANGER' ? 'danger' : ''}`;
  div.textContent = `${new Date().toLocaleTimeString()} T${data.tagId} ${data.zone} ${(data.distanceM||0).toFixed(1)}m`;
  log.prepend(div);
  if (log.children.length > 100) log.lastChild.remove();
}

// --- 설정 적용 ---
function applyConfig() {
  const tlLat = parseFloat(document.getElementById('tl-lat').value);
  const tlLon = parseFloat(document.getElementById('tl-lon').value);
  const brLat = parseFloat(document.getElementById('br-lat').value);
  const brLon = parseFloat(document.getElementById('br-lon').value);
  if ([tlLat, tlLon, brLat, brLon].some(isNaN)) {
    alert('GPS 좌표를 모두 입력해주세요.');
    return;
  }
  mapBounds = { top_left: [tlLat, tlLon], bot_right: [brLat, brLon] };
  fetch('/config/bounds', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      top_left: [tlLat, tlLon],
      bot_right: [brLat, brLon],
      img_width: imgW,
      img_height: imgH,
    }),
  });
  redraw();
}

document.getElementById('map-upload').addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const img = new Image();
  img.onload = () => {
    mapImage = img;
    imgW = img.naturalWidth;
    imgH = img.naturalHeight;
    redraw();
  };
  img.src = URL.createObjectURL(file);
});

connectSSE();
```

- [ ] **Step 3: 브라우저에서 확인**

서버 실행 후 `http://localhost:8000` 접속. 지도 이미지 업로드 후 GPS 좌표 입력 → 적용.

- [ ] **Step 4: 커밋**

```powershell
git add tools\static\
git commit -m "feat: add real-time dashboard with map background and SSE updates"
```

---

## Task 6: 앵커 펌웨어 (anchor_node.ino)

**Files:**
- Create: `uwb_phase1_starter/anchor_node/anchor_node.ino`

> DW3000 측정 API는 보드 제조사마다 다릅니다. `setupUwbReal()` / `pollUwbReal()` 안의 TODO를 제조사 DS-TWR 예제로 채워주세요. 나머지 로직(GPS, 안전, WiFi)은 완성된 코드입니다.

- [ ] **Step 1: anchor_node.ino 작성**

`uwb_phase1_starter/anchor_node/anchor_node.ino`:
```cpp
/*
  UWB Phase 1 — Anchor Node
  대상: ESP32 + DW3000 + NEO-M8N GPS

  각 앵커당 변경 사항:
    ANCHOR_ID   "ANC-001" / "ANC-002" / "ANC-003"
    ANCHOR_ADDR 0xE001   / 0xE002   / 0xE003
    IS_BEACON_MASTER: 앵커 중 1개(ANC-001)만 true

  GPS: ESP32 Serial2 (RX=16, TX=17) ← 보드에 따라 조정
  릴레이: ANC-001(BEACON_MASTER)에만 연결

  UWB 라이브러리 연동:
    setupUwbReal() 과 pollUwbReal() 안의 TODO 블록을
    보드 제조사의 DS-TWR Initiator/Ranger 예제로 채우세요.
    거리 측정 완료 시 → onUwbRange(tagId, distanceM, rssi)
    타임아웃 시      → onUwbNoRange(tagId)
*/

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <TinyGPS++.h>

// ===================== USER CONFIG =====================
#define USE_FAKE_SERIAL_RANGES 1  // 1: 시리얼 입력으로 테스트, 0: 실제 DW3000

static const char* ANCHOR_ID   = "ANC-001";
static const uint16_t ANCHOR_ADDR = 0xE001;
static const bool IS_BEACON_MASTER = true; // ANC-001만 true

const char* WIFI_SSID  = "후니";
const char* WIFI_PASS  = "12345678*";
const char* SERVER_URL = "http://192.168.0.10:8000/range";

static const int RELAY_PIN        = 26;
static const bool RELAY_ACTIVE_LOW = false;
static const int STATUS_LED_PIN   = 2;

// GPS 시리얼 핀 (ESP32 기본 Serial2)
static const int GPS_RX_PIN = 16;
static const int GPS_TX_PIN = 17;
static const uint32_t GPS_BAUD = 9600;

// TDMA
static const uint32_t SLOT_MS         = 5;
static const uint8_t  TAG_SLOT_COUNT  = 2;   // 태그 늘리면 이 값만 증가
static const uint32_t CYCLE_MS        = (uint32_t)TAG_SLOT_COUNT * SLOT_MS;

// 태그 ID 목록
static const uint16_t TAG_IDS[]  = {0x1001, 0x1002};
static const size_t   TAG_COUNT  = sizeof(TAG_IDS) / sizeof(TAG_IDS[0]);

// 안전 정책 (equipment_node.ino와 동일)
static const float   DANGER_ON_M           = 3.00f;
static const float   DANGER_OFF_M          = 3.50f;
static const uint8_t SAFE_SAMPLE_COUNT_TO_OFF = 3;
static const uint32_t NO_RANGE_HOLD_MS     = 1500;
static const uint32_t TAG_STALE_MS         = 5000;
static const bool    RELAY_ON_WHILE_FAULT  = true;
static const uint32_t HEARTBEAT_MS         = 1000;
// =======================================================

enum TagZone : uint8_t { ZONE_UNKNOWN=0, ZONE_SAFE, ZONE_WARNING, ZONE_DANGER, ZONE_FAULT };

struct TagState {
  uint16_t id;
  bool     hasDistance;
  float    lastDistanceM;
  int16_t  lastRssi;
  uint32_t lastSeenMs;
  uint32_t lastNoRangeMs;
  bool     dangerLatched;
  bool     noRange;
  bool     fault;
  uint8_t  safeCount;
  uint32_t seq;
};

TagState tags[TAG_COUNT];
bool     relayOn         = false;
uint32_t lastHeartbeatMs = 0;
uint32_t bootMs          = 0;

TinyGPSPlus gps;
double currentLat = 0.0;
double currentLon = 0.0;
bool   gpsValid   = false;

// ---- 안전 로직 (equipment_node.ino에서 그대로 이식) ----
String tagIdHex(uint16_t id) {
  char buf[8]; snprintf(buf, sizeof(buf), "%04X", id); return String(buf);
}
int findTagIndex(uint16_t id) {
  for (size_t i = 0; i < TAG_COUNT; i++) if (tags[i].id == id) return (int)i;
  return -1;
}
void writeRelay(bool on) {
  relayOn = on;
  bool level = RELAY_ACTIVE_LOW ? !on : on;
  digitalWrite(RELAY_PIN, level ? HIGH : LOW);
  digitalWrite(STATUS_LED_PIN, on ? HIGH : LOW);
}
bool tagRequiresRelay(const TagState& t) {
  if (t.dangerLatched) return true;
  if (RELAY_ON_WHILE_FAULT && t.fault) return true;
  return false;
}
bool systemRequiresRelay() {
  for (size_t i = 0; i < TAG_COUNT; i++) if (tagRequiresRelay(tags[i])) return true;
  return false;
}
const char* zoneName(const TagState& t) {
  if (t.fault) return "FAULT";
  if (t.dangerLatched) return "DANGER";
  if (!t.hasDistance) return "UNKNOWN";
  if (t.lastDistanceM < DANGER_OFF_M) return "WARNING";
  return "SAFE";
}

void postToServer(const TagState& t, const char* eventType) {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!gpsValid) return;

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");

  char payload[512];
  snprintf(payload, sizeof(payload),
    "{\"anchorId\":\"%s\","
    "\"lat\":%.7f,\"lon\":%.7f,"
    "\"tagId\":\"%s\","
    "\"event\":\"%s\","
    "\"seq\":%lu,"
    "\"distanceM\":%.3f,"
    "\"danger\":%s,\"relay\":%s,"
    "\"noRange\":%s,\"fault\":%s,"
    "\"zone\":\"%s\","
    "\"rssi\":%d,\"uptimeMs\":%lu}",
    ANCHOR_ID,
    currentLat, currentLon,
    tagIdHex(t.id).c_str(),
    eventType, (unsigned long)t.seq,
    t.hasDistance ? t.lastDistanceM : -1.0f,
    t.dangerLatched ? "true":"false",
    relayOn ? "true":"false",
    t.noRange ? "true":"false",
    t.fault ? "true":"false",
    zoneName(t),
    t.lastRssi,
    (unsigned long)(millis() - bootMs));

  http.POST(payload);
  http.end();
}

void applyRelayAndPost(TagState& t, const char* eventType) {
  bool required = systemRequiresRelay();
  if (required != relayOn) writeRelay(required);
  Serial.printf("{\"anchor\":\"%s\",\"tag\":\"%s\",\"event\":\"%s\",\"dist\":%.3f,\"relay\":%s}\n",
    ANCHOR_ID, tagIdHex(t.id).c_str(), eventType,
    t.hasDistance ? t.lastDistanceM : -1.0f, relayOn ? "true":"false");
  postToServer(t, eventType);
}

void onUwbRange(uint16_t tagId, float distanceM, int16_t rssi = 0) {
  int idx = findTagIndex(tagId);
  if (idx < 0) return;
  TagState& t = tags[idx];
  t.seq++; t.hasDistance = true; t.lastDistanceM = distanceM;
  t.lastRssi = rssi; t.lastSeenMs = millis(); t.noRange = false;
  bool wasDanger = t.dangerLatched, wasFault = t.fault;

  if (distanceM <= DANGER_ON_M) {
    t.dangerLatched = true; t.fault = false; t.safeCount = 0;
    applyRelayAndPost(t, wasDanger ? "DANGER_UPDATE" : "DANGER_ENTER");
    return;
  }
  if (distanceM >= DANGER_OFF_M) {
    if (t.dangerLatched || t.fault) {
      if (t.safeCount < 255) t.safeCount++;
      if (t.safeCount >= SAFE_SAMPLE_COUNT_TO_OFF) {
        t.dangerLatched = false; t.fault = false; t.safeCount = 0;
        applyRelayAndPost(t, (wasDanger || wasFault) ? "DANGER_EXIT" : "SAFE_UPDATE");
      } else {
        applyRelayAndPost(t, "SAFE_CANDIDATE");
      }
    } else {
      t.safeCount = 0;
      applyRelayAndPost(t, "SAFE_UPDATE");
    }
    return;
  }
  t.safeCount = 0; t.fault = false;
  applyRelayAndPost(t, t.dangerLatched ? "DANGER_HOLD" : "WARNING_UPDATE");
}

void onUwbNoRange(uint16_t tagId) {
  int idx = findTagIndex(tagId);
  if (idx < 0) return;
  TagState& t = tags[idx];
  t.seq++; t.noRange = true; t.lastNoRangeMs = millis();
  bool nearBeforeLoss = t.hasDistance && (t.lastDistanceM < DANGER_OFF_M);
  bool mustHold = t.dangerLatched || nearBeforeLoss;
  if (mustHold && (millis() - t.lastSeenMs >= NO_RANGE_HOLD_MS)) {
    t.fault = true;
    if (RELAY_ON_WHILE_FAULT) t.dangerLatched = true;
    applyRelayAndPost(t, "NO_RANGE_FAULT");
  } else {
    applyRelayAndPost(t, "NO_RANGE_HOLD");
  }
}

void checkStaleTags() {
  uint32_t now = millis();
  for (size_t i = 0; i < TAG_COUNT; i++) {
    TagState& t = tags[i];
    if (!t.hasDistance) continue;
    if (now - t.lastSeenMs > TAG_STALE_MS && !t.noRange) {
      t.noRange = true; t.seq++;
      Serial.printf("{\"anchor\":\"%s\",\"tag\":\"%s\",\"event\":\"TAG_STALE\"}\n", ANCHOR_ID, tagIdHex(t.id).c_str());
    }
  }
}

void heartbeat() {
  uint32_t now = millis();
  if (now - lastHeartbeatMs < HEARTBEAT_MS) return;
  lastHeartbeatMs = now;
  Serial.printf("{\"anchor\":\"%s\",\"event\":\"HEARTBEAT\",\"relay\":%s,\"lat\":%.7f,\"lon\":%.7f,\"gpsValid\":%s}\n",
    ANCHOR_ID, relayOn?"true":"false", currentLat, currentLon, gpsValid?"true":"false");
}

// ---- GPS ----
void pollGps() {
  while (Serial2.available()) {
    if (gps.encode(Serial2.read())) {
      if (gps.location.isValid()) {
        currentLat = gps.location.lat();
        currentLon = gps.location.lng();
        gpsValid   = true;
      }
    }
  }
}

// ---- FAKE SERIAL (테스트용) ----
void pollFakeSerialRanges() {
#if USE_FAKE_SERIAL_RANGES
  static String line;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      line.trim();
      if (line.length() > 0) {
        char idBuf[16]={0}, valBuf[16]={0};
        if (sscanf(line.c_str(), "%15s %15s", idBuf, valBuf) >= 2) {
          uint16_t id = (uint16_t)strtol(idBuf, nullptr, 16);
          String val = String(valBuf); val.toUpperCase();
          if (val == "NR") onUwbNoRange(id);
          else             onUwbRange(id, val.toFloat(), 0);
        }
      }
      line = "";
    } else { line += c; }
  }
#endif
}

// ---- 실제 DW3000 (보드 제조사 라이브러리 연동) ----
void setupUwbReal() {
#if !USE_FAKE_SERIAL_RANGES
  // TODO:
  // 1) SPI + DW3000 초기화 (제조사 라이브러리 사용)
  // 2) 자신의 short address = ANCHOR_ADDR 설정
  // 3) IS_BEACON_MASTER == true인 앵커: Beacon 전송 타이머 설정
  // 4) 거리 측정 완료 콜백 → onUwbRange(targetId, distanceM, rssi)
  // 5) 타임아웃 콜백        → onUwbNoRange(targetId)
#endif
}

void pollUwbReal() {
#if !USE_FAKE_SERIAL_RANGES
  // TODO:
  // TDMA 슬롯 방식:
  //   IS_BEACON_MASTER 앵커(ANC-001): 매 CYCLE_MS마다 Beacon 브로드캐스트
  //   모든 앵커: Beacon 이후 각 슬롯(slot * SLOT_MS)에서 해당 태그와 DS-TWR 수행
  //   슬롯 번호 = tagIndex (0 ~ TAG_SLOT_COUNT-1)
#endif
}

// ---- WiFi ----
void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
    delay(250); Serial.print('.');
  }
  Serial.println();
  Serial.printf("WiFi: %s\n", WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString().c_str() : "연결 실패");
}

void setup() {
  bootMs = millis();
  Serial.begin(115200);
  delay(500);

  if (IS_BEACON_MASTER) {
    pinMode(RELAY_PIN, OUTPUT);
    pinMode(STATUS_LED_PIN, OUTPUT);
    writeRelay(false);
  }

  for (size_t i = 0; i < TAG_COUNT; i++) {
    tags[i] = {TAG_IDS[i], false, 999.0f, 0, 0, 0, false, false, false, 0, 0};
  }

  Serial2.begin(GPS_BAUD, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
  connectWifi();
  setupUwbReal();

  Serial.printf("앵커 %s 시작 (IS_BEACON_MASTER=%d)\n", ANCHOR_ID, IS_BEACON_MASTER);
  Serial.println("테스트 입력 예시: 1001 2.80 / 1001 3.80 / 1001 NR");
}

void loop() {
  pollGps();
  pollFakeSerialRanges();
  pollUwbReal();
  checkStaleTags();
  heartbeat();
  delay(5);
}
```

- [ ] **Step 2: 시리얼 테스트 (USE_FAKE_SERIAL_RANGES=1)**

Arduino IDE로 ANC-001에 플래시 후 시리얼 모니터 115200 baud:
```
1001 2.80  →  DANGER_ENTER 출력, 릴레이 ON
1001 3.80  →  SAFE_CANDIDATE (3회 필요)
1001 3.80
1001 3.80  →  DANGER_EXIT, 릴레이 OFF
1001 NR    →  NO_RANGE_HOLD
```

- [ ] **Step 3: GPS 테스트**

`USE_FAKE_SERIAL_RANGES=1` 상태에서 GPS 안테나 실외 배치 후:
```
{"anchor":"ANC-001","event":"HEARTBEAT","relay":false,"lat":37.503400,"lon":127.023400,"gpsValid":true}
```
`gpsValid:true` 와 실제 위경도 확인.

- [ ] **Step 4: 서버 POST 테스트**

`USE_FAKE_SERIAL_RANGES=1`, `USE_WIFI_POST` (server.py 실행 중) 상태에서:
```
1001 2.80  입력 → 서버 http://localhost:8000/state 에서 태그 상태 확인
```

- [ ] **Step 5: 커밋**

```powershell
git add anchor_node\
git commit -m "feat: add anchor firmware with GPS, safety state machine, TDMA hooks, and WiFi POST"
```

---

## Task 7: 태그 펌웨어 (tag_node.ino)

**Files:**
- Create: `uwb_phase1_starter/tag_node/tag_node.ino`

- [ ] **Step 1: tag_node.ino 작성**

`uwb_phase1_starter/tag_node/tag_node.ino`:
```cpp
/*
  UWB Phase 1 — Tag Node (Worker Tag)
  대상: ESP32 + DW3000

  태그마다 변경:
    MY_SHORT_ADDR  0x1001 (T1) / 0x1002 (T2)
    TAG_SLOT_COUNT 앵커 anchor_node.ino 와 동일하게 유지

  DW3000 라이브러리 연동:
    setupUwbReal() / loopUwbReal() 안의 TODO를
    보드 제조사의 DS-TWR Responder 예제로 채우세요.
    슬롯 번호 = MY_SHORT_ADDR % TAG_SLOT_COUNT
    Beacon 수신 후 (slot * SLOT_MS) 대기 → 응답 전송
*/

#include <Arduino.h>

// ===================== USER CONFIG =====================
static const uint16_t MY_SHORT_ADDR  = 0x1001;   // 태그마다 변경
static const uint16_t ANCHOR_ADDR    = 0xE001;   // Beacon master 앵커
static const uint16_t NETWORK_ID     = 0xBEEF;

static const uint8_t  TAG_SLOT_COUNT = 2;         // anchor_node.ino 와 동일
static const uint32_t SLOT_MS        = 5;
static const int      STATUS_LED_PIN = 2;
// =======================================================

uint8_t mySlot;

void setupUwbReal() {
  // TODO:
  // 1) SPI + DW3000 초기화
  // 2) short address = MY_SHORT_ADDR 설정
  // 3) network ID = NETWORK_ID 설정
  // 4) Responder/RX 모드 시작
  //    - Beacon(from ANCHOR_ADDR) 수신 대기
  //    - Beacon 수신 시: delay(mySlot * SLOT_MS) 후 DS-TWR 응답
  // 5) LED: 응답 전송 시 깜빡임 (선택)
}

void loopUwbReal() {
  // TODO: 제조사 라이브러리의 responder loop 호출
}

void setup() {
  Serial.begin(115200);
  mySlot = MY_SHORT_ADDR % TAG_SLOT_COUNT;
  pinMode(STATUS_LED_PIN, OUTPUT);

  setupUwbReal();

  Serial.printf("태그 0x%04X 시작 — TDMA 슬롯 %d (대기 %dms)\n",
    MY_SHORT_ADDR, mySlot, mySlot * SLOT_MS);
}

void loop() {
  loopUwbReal();
  delay(1);
}
```

- [ ] **Step 2: T1(0x1001), T2(0x1002) 각각 플래시 후 시리얼 확인**

```
태그 0x1001 시작 — TDMA 슬롯 1 (대기 5ms)
태그 0x1002 시작 — TDMA 슬롯 0 (대기 0ms)
```

- [ ] **Step 3: 커밋**

```powershell
git add tag_node\
git commit -m "feat: add tag firmware with TDMA slot responder structure"
```

---

## Task 8: 통합 테스트

**하드웨어 필요: 앵커 3개(GPS 포함) + 태그 2개 + PC**

- [ ] **Step 1: Phase A — 시리얼 가짜 입력으로 대시보드 확인**

1. `python tools/server.py` 실행
2. `USE_FAKE_SERIAL_RANGES=1` 앵커 1개 플래시
3. GPS 좌표 수동 고정 (코드에서 `currentLat=37.5034; currentLon=127.0234; gpsValid=true;`)
4. 시리얼 입력으로 각각 3개 앵커 POST 시뮬레이션 (PowerShell):

```powershell
$b1='{"anchorId":"ANC-001","lat":37.5034,"lon":127.0228,"tagId":"1001","distanceM":2.50,"zone":"DANGER","relay":true}'
$b2='{"anchorId":"ANC-002","lat":37.5034,"lon":127.0242,"tagId":"1001","distanceM":4.10,"zone":"SAFE","relay":false}'
$b3='{"anchorId":"ANC-003","lat":37.5025,"lon":127.0235,"tagId":"1001","distanceM":3.80,"zone":"SAFE","relay":false}'
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $b1
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $b2
Invoke-WebRequest -Uri http://localhost:8000/range -Method POST -ContentType "application/json" -Body $b3
```

5. 브라우저(`http://localhost:8000`)에서 지도 위 TAG-1001 마커 확인

통과 조건:
- 대시보드에 태그 마커 표시됨
- 사이드바에 `DANGER 2.50m` 표시
- 상단 배지 `⚠ RELAY ON` 으로 변경

- [ ] **Step 2: Phase B — GPS + UWB 실제 통합**

1. 앵커 3개에 GPS 연결 후 실외 배치 (굴착기 부착)
2. `USE_FAKE_SERIAL_RANGES=0`, `USE_WIFI_POST=1` 로 빌드/플래시
3. 제조사 DS-TWR 라이브러리 `setupUwbReal()` / `pollUwbReal()` 에 연동
4. 태그 2개 플래시
5. 대시보드 열고 카카오맵 스크린샷 + GPS 바운드 입력
6. 태그를 앵커 근처 1m / 3m / 5m 지점으로 이동하면서 지도 위 마커 이동 확인

통과 조건 (TEST_PLAN.md Phase B 기준):
- 실제 2.8m → 릴레이 ON
- 실제 3.7m → 릴레이 OFF (3회 연속 후)
- 지도 위 마커가 실제 위치와 시각적으로 일치

- [ ] **Step 3: 최종 커밋**

```powershell
git add .
git commit -m "feat: complete UWB+GPS positioning system — anchors, tags, server, dashboard"
```
