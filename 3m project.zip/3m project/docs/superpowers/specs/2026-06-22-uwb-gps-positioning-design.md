# UWB + GPS 실시간 위치 추적 대시보드 설계

**날짜:** 2026-06-22  
**프로젝트:** 3m 안전 구역 시스템 — Phase 1 확장  
**상태:** 설계 확정, 구현 예정

---

## 1. 목표

굴착기에 부착된 UWB 앵커 3개와 GPS 모듈을 조합하여, 작업자 태그의 실제 현장 위치를 카카오맵/구글맵 배경 이미지 위에 실시간으로 표시한다. 3m 이내 진입 시 릴레이는 서버를 거치지 않고 앵커에서 즉시 작동한다.

---

## 2. 하드웨어 구성

### 앵커 3개 — 굴착기에 부착 (이동)

| 장치 | 주소 | 추가 모듈 | 비고 |
|------|------|-----------|------|
| A0 | 0xE001 | ESP32 + DW3000 + NEO-M8N GPS | 릴레이 연결 |
| A1 | 0xE002 | ESP32 + DW3000 + NEO-M8N GPS | |
| A2 | 0xE003 | ESP32 + DW3000 + NEO-M8N GPS | |

- GPS 모듈: NEO-M8N 또는 NEO-6M, UART 연결 (ESP32 RX2/TX2)
- 앵커 3개 모두 GPS를 가지므로 heading 계산 없이 각자 독립 위치 보고
- 굴착기가 이동·회전해도 GPS가 실시간으로 앵커 위치를 업데이트

### 태그 2개 — 작업자 착용 (이동)

| 장치 | 주소 | 비고 |
|------|------|------|
| T1 | 0x1001 | ESP32 + DW3000 |
| T2 | 0x1002 | ESP32 + DW3000 |

- GPS 없음, DW3000만
- 조끼·안전모에 부착
- 나중에 T3(0x1003), T4(0x1004) 추가 가능 (펌웨어 수정 없이 슬롯 자동 계산)

### 현장 PC

- Python 서버 + 브라우저 대시보드
- 앵커들과 동일한 WiFi 네트워크 (공유기 또는 핫스팟)

---

## 3. 통신 구조 — TDMA 슬롯 방식

### 전체 흐름

```
① 앵커(A0) Beacon 브로드캐스트 (매 CYCLE_MS마다)
        ↓ UWB
② 태그들이 Beacon 수신 → 자기 슬롯 계산: slot = tagShortAddr % TAG_SLOT_COUNT
        ↓ 각자 할당 시간에 UWB 브로드캐스트
③ 앵커 3개가 동시에 태그 신호 수신 → 거리 계산
        ↓ 로컬 판단 (서버 없음)
④ 거리 ≤ 3.0m → 릴레이 즉시 ON  (반응시간: ~슬롯 1개 = 5ms)
        ↓ WiFi
⑤ 앵커 → HTTP POST: {anchorId, lat, lon, tagId, distanceM} → Python 서버
        ↓ SSE
⑥ Python 서버 → 삼변측량 → 브라우저로 실시간 push → 지도에 위치 표시
```

### TDMA 파라미터

| 파라미터 | 값 | 설명 |
|----------|-----|------|
| SLOT_MS | 5 | 태그 1개당 슬롯 시간 |
| TAG_SLOT_COUNT | 현재 2, 최대 100 | 슬롯 수 = 최대 태그 수 |
| CYCLE_MS | TAG_SLOT_COUNT × SLOT_MS | 전체 사이클 (현재 10ms) |
| 릴레이 반응시간 | ≤ CYCLE_MS | 현재 ~10ms |

슬롯 확장 시 반응시간: 100태그 → 500ms (사람 보행속도 1.4m/s 기준 0.7m 이동, 안전 허용 범위 내)

---

## 4. 안전 로직

기존 `equipment_node.ino`의 상태 머신을 앵커 펌웨어에 유지한다.

- `distanceM ≤ 3.0m` → `dangerLatched = true`, 릴레이 ON 즉시
- `3.0m < distanceM < 3.5m` → 히스테리시스 구간, 이전 상태 유지
- `distanceM ≥ 3.5m` 3회 연속 → 릴레이 OFF
- No Range (태그 응답 없음, 1500ms 이상) → FAULT, 릴레이 ON 유지
- 태그 5초 무응답 → TAG_STALE 이벤트

릴레이 판단은 **앵커 로컬**에서 수행. WiFi/서버 단절 시에도 안전 기능 유지.

---

## 5. 펌웨어 구성

### anchor_node.ino (신규 — 기존 equipment_node.ino 교체)

**역할:**
- GPS 읽기: TinyGPS++ 라이브러리, Serial2(RX2/TX2)
- Beacon 전송: A0가 매 CYCLE_MS마다 동기화 신호 브로드캐스트 (A1, A2도 수신)
- 태그 거리 측정: 각 앵커가 태그 슬롯 시간에 독립적으로 TWR 수행. A0·A1·A2 모두 같은 슬롯에서 각자 응답을 수신해 거리를 계산. (보드 제조사 라이브러리의 스니핑/수신 API 활용 — 구체적 방식은 구현 단계에서 확정)
- 안전 로직: 기존 TagState 상태 머신 그대로 유지
- WiFi POST: `{anchorId, lat, lon, tagId, distanceM, danger, relay, zone, seq, uptimeMs}`

**주요 설정 상수:**

```cpp
#define SLOT_MS            5
#define TAG_SLOT_COUNT     2       // 현재, 태그 추가 시 증가
#define GPS_SERIAL         Serial2
#define GPS_BAUD           9600
static const char* ANCHOR_ID = "ANC-001";   // 각 앵커마다 다르게
```

### tag_node.ino (신규 — 기존 worker_tag_responder_template.ino 교체)

**역할:**
- Beacon 수신 대기
- 슬롯 계산: `mySlot = MY_SHORT_ADDR % TAG_SLOT_COUNT`
- 슬롯 시간에 UWB 응답 전송

**주요 설정 상수:**

```cpp
static const uint16_t MY_SHORT_ADDR = 0x1001;  // 태그마다 다르게
static const uint16_t ANCHOR_ADDR   = 0xE001;  // 메인 앵커 주소
```

---

## 6. Python 서버 (tools/server.py — server_log.py 확장)

### 엔드포인트

| 경로 | 메서드 | 설명 |
|------|--------|------|
| `/range` | POST | 앵커에서 GPS+거리 수신, 삼변측량 트리거 |
| `/dashboard` | GET | 대시보드 HTML 제공 |
| `/events` | GET | SSE 스트림 (태그 위치 실시간 push) |
| `/config` | POST | 지도 이미지 업로드 + GPS 바운드 설정 |

### 삼변측량 로직

```python
# 앵커 GPS → 로컬 XY 변환 (미터 단위, A0 기준 원점)
# 태그별로 3개 앵커 거리 수집 → 최소제곱법으로 XY 계산
# XY → GPS 역변환 → 픽셀 좌표 변환 (GPS 바운드 기준)
```

3개 앵커 중 2개 이상 거리 수신 시 위치 계산. 1개만 수신 시 위치 계산 생략, 거리만 표시.

### GPS ↔ 픽셀 변환

```python
# 사용자가 입력한 지도 이미지 바운드:
#   top_left  = (lat0, lon0)  ← 이미지 좌상단
#   bot_right = (lat1, lon1)  ← 이미지 우하단
# 선형 보간으로 GPS → 픽셀 변환
px = (lon - lon0) / (lon1 - lon0) * img_width
py = (lat0 - lat) / (lat0 - lat1) * img_height
```

---

## 7. 브라우저 대시보드

### 기능

- **설정 패널 (최초 1회):** 지도 이미지 업로드, 좌상단·우하단 GPS 좌표 입력
- **지도 뷰:** 배경 이미지 위에 앵커(파란 사각형), 태그(색깔 원) 실시간 표시
- **위험 반경:** 각 앵커 기준 3m 원 (픽셀로 변환해서 표시)
- **상태 바:** 릴레이 ON/OFF, 태그별 거리·Zone
- **경보:** DANGER 진입 시 화면 빨간 테두리 + 경고 텍스트

### 기술 스택

- 순수 HTML + JavaScript (프레임워크 없음)
- Server-Sent Events (SSE)로 실시간 업데이트
- Canvas 또는 절대위치 div로 지도 위 마커 표시
- Python Flask 또는 기존 http.server 확장으로 제공

---

## 8. 확장성

| 항목 | 현재 | 최대 |
|------|------|------|
| 태그 수 | 2 | ~100 (TAG_SLOT_COUNT 상수만 변경) |
| 앵커 수 | 3 | 제한 없음 (삼변측량은 3개만 사용, 나머지는 중복 보완) |
| 릴레이 반응시간 | ~10ms | 100태그 시 ~500ms |

태그 추가 시 변경 사항:
1. 새 태그 펌웨어에 `MY_SHORT_ADDR` 설정
2. 앵커 펌웨어 `TAG_SLOT_COUNT` 증가
3. 서버/대시보드는 자동 인식

---

## 9. 추가 구매 목록

| 품목 | 수량 | 비고 |
|------|------|------|
| NEO-M8N 또는 NEO-6M GPS 모듈 | 3개 | 앵커당 1개 |
| GPS 외장 안테나 | 3개 | 굴착기 금속 차폐 고려 |

DW3000 보드 추가 구매 없음 (현재 5개로 앵커3+태그2 구성).

---

## 10. 구현 순서 (제안)

1. GPS 모듈 연결 + TinyGPS++ 테스트 (앵커 1개)
2. TDMA Beacon/슬롯 펌웨어 (앵커 1 + 태그 1 우선)
3. 안전 로직 이식 + 릴레이 테스트
4. WiFi HTTP POST + Python 서버 삼변측량
5. 브라우저 대시보드 (지도 + 마커)
6. 3앵커 + 2태그 통합 테스트
