/**
 * anchor_node.ino  —  UWB 앵커 (Initiator / 거리 측정자)
 * 대상: Makerfabs ESP32 UWB DW3000
 *
 * 라이브러리:
 *   https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000
 *   "Dw3000" 폴더를 Arduino/libraries/ 에 복사
 *
 * 앵커마다 변경:
 *   ANCHOR_ID, MY_ADDR, IS_BEACON_MASTER
 *   WIFI_SSID, WIFI_PASSWORD, SERVER_URL
 */

#include "dw3000.h"
#include <SPI.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <TinyGPS++.h>
#include <ArduinoJson.h>

extern SPISettings _fastSPI;
extern dwt_txconfig_t txconfig_options;

// ─── 핀 (Makerfabs ESP32 UWB DW3000 고정) ──────────────────────────
#define PIN_RST  27
#define PIN_IRQ  34
#define PIN_SS    4

// ─── 사용자 설정 ────────────────────────────────────────────────────
static const char* WIFI_SSID      = "후니";
static const char* WIFI_PASSWORD  = "12345678*";
static const char* SERVER_URL     = "http://203.229.34.138:8000/range"; // ← PC IP로 변경

static const char* ANCHOR_ID      = "ANC-001";  // ANC-001 / ANC-002 / ANC-003
static const uint16_t MY_ADDR     = 0xE001;      // 0xE001 / 0xE002 / 0xE003
static const bool IS_BEACON_MASTER = true;        // ANC-001 만 true

#define GPS_RX_PIN  16
#define GPS_TX_PIN  17
#define GPS_BAUD    9600
#define RELAY_PIN   26

// ─── TDMA 파라미터 ──────────────────────────────────────────────────
#define TAG_SLOT_COUNT  1                   // 태그 수 (늘리면 이 값만 변경)
#define INTER_SLOT_MS  20                   // 슬롯 간 태그 전환 대기 시간

static const uint16_t TAG_ADDRS[TAG_SLOT_COUNT] = { 0x1001 };
static const char*    TAG_IDS[TAG_SLOT_COUNT]   = { "TAG-001" };

// ─── 안전 상태 머신 임계값 ──────────────────────────────────────────
#define DANGER_DIST_M   3.0f
#define SAFE_DIST_M     3.5f
#define SAFE_COUNT_REQ  3
#define NO_RANGE_MS     1500

// ─── DW3000 RF 파라미터 ─────────────────────────────────────────────
#define TX_ANT_DLY                  16385
#define RX_ANT_DLY                  16385
#define POLL_TX_TO_RESP_RX_DLY_UUS  600
#define RESP_RX_TIMEOUT_UUS         3000   // 응답 대기 시간

#define ALL_MSG_COMMON_LEN    10
#define ALL_MSG_SN_IDX         2
#define RESP_MSG_POLL_RX_TS_IDX  10
#define RESP_MSG_RESP_TX_TS_IDX  14
#define RESP_MSG_RESP_ADDR_IDX   18   // 응답 프레임의 태그 주소 위치

static dwt_config_t dw_config = {
    5,                /* Channel number */
    DWT_PLEN_128,     /* Preamble length */
    DWT_PAC8,
    9,                /* TX preamble code */
    9,                /* RX preamble code */
    1,
    DWT_BR_6M8,
    DWT_PHRMODE_STD,
    DWT_PHRRATE_STD,
    (129 + 8 - 8),
    DWT_STS_MODE_OFF,
    DWT_STS_LEN_64,
    DWT_PDOA_M0
};

// Poll 프레임: bytes 10-11 = 대상 태그 주소
static uint8_t tx_poll_msg[] = {
    0x41, 0x88, 0, 0xCA, 0xDE, 'W','A','V','E', 0xE0,
    0, 0   // bytes 10-11: target tag address
};
// 수신 응답 검증용 템플릿 (첫 10바이트만 비교)
static uint8_t rx_resp_check[] = {
    0x41, 0x88, 0, 0xCA, 0xDE, 'V','E','W','A', 0xE1
};

static uint8_t  rx_buffer[24];
static uint8_t  frame_seq_nb = 0;
static uint32_t status_reg   = 0;

// ─── 태그 상태 ──────────────────────────────────────────────────────
struct TagState {
    bool          dangerLatched;
    int           safeCount;
    float         lastDist;
    bool          relay;
    unsigned long lastRangeMs;
    bool          fault;
    uint32_t      seq;
};
static TagState tagStates[TAG_SLOT_COUNT] = {};

// ─── GPS ────────────────────────────────────────────────────────────
TinyGPSPlus    gps;
HardwareSerial gpsSerial(2);
static double  anchorLat = 0.0;
static double  anchorLon = 0.0;
static bool    gpsValid  = false;

// ─── DW3000 초기화 ──────────────────────────────────────────────────
void dw3000_hw_init() {
    _fastSPI = SPISettings(7000000L, MSBFIRST, SPI_MODE0);
    spiBegin(PIN_IRQ, PIN_RST);
    spiSelect(PIN_SS);
    delay(2);

    dwt_softreset();
    delay(2);

    if (!dwt_checkidlerc()) {
        Serial.println("[DW3000] IDLE FAILED — 배선 확인");
        while (1);
    }
    if (dwt_initialise(DWT_DW_INIT) == DWT_ERROR) {
        Serial.println("[DW3000] INIT FAILED");
        while (1);
    }

    dwt_setleds(DWT_LEDS_ENABLE | DWT_LEDS_INIT_BLINK);

    if (dwt_configure(&dw_config)) {
        Serial.println("[DW3000] CONFIG FAILED");
        while (1);
    }

    dwt_configuretxrf(&txconfig_options);
    dwt_setrxantennadelay(RX_ANT_DLY);
    dwt_settxantennadelay(TX_ANT_DLY);
    dwt_setlnapamode(DWT_LNA_ENABLE | DWT_PA_ENABLE);

    Serial.printf("[DW3000] 앵커 %s 초기화 완료\n", ANCHOR_ID);
}

// ─── SS-TWR 거리 측정 (initiator) ───────────────────────────────────
// targetAddr 태그에 Poll 전송 → 거리(m) 반환. 실패 시 -1.0f
float dw3000_measure_distance(uint16_t targetAddr) {
    // Poll 프레임 bytes 10-11 에 대상 태그 주소 삽입
    tx_poll_msg[10] = (uint8_t)(targetAddr >> 8);
    tx_poll_msg[11] = (uint8_t)(targetAddr & 0xFF);
    tx_poll_msg[ALL_MSG_SN_IDX] = frame_seq_nb;

    dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_TXFRS_BIT_MASK);
    dwt_writetxdata(sizeof(tx_poll_msg), tx_poll_msg, 0);
    dwt_writetxfctrl(sizeof(tx_poll_msg), 0, 1);
    dwt_setrxaftertxdelay(POLL_TX_TO_RESP_RX_DLY_UUS);
    dwt_setrxtimeout(RESP_RX_TIMEOUT_UUS);
    dwt_starttx(DWT_START_TX_IMMEDIATE | DWT_RESPONSE_EXPECTED);

    // 응답 또는 오류/타임아웃 대기
    while (!((status_reg = dwt_read32bitreg(SYS_STATUS_ID)) &
             (SYS_STATUS_RXFCG_BIT_MASK | SYS_STATUS_ALL_RX_TO | SYS_STATUS_ALL_RX_ERR)));

    frame_seq_nb++;

    if (!(status_reg & SYS_STATUS_RXFCG_BIT_MASK)) {
        dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_ALL_RX_TO | SYS_STATUS_ALL_RX_ERR);
        return -1.0f;
    }

    dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_RXFCG_BIT_MASK);
    uint32_t frame_len = dwt_read32bitreg(RX_FINFO_ID) & RXFLEN_MASK;

    if (frame_len > sizeof(rx_buffer)) return -1.0f;
    dwt_readrxdata(rx_buffer, frame_len, 0);
    rx_buffer[ALL_MSG_SN_IDX] = 0;

    // 응답 프레임 시그니처 확인
    if (memcmp(rx_buffer, rx_resp_check, ALL_MSG_COMMON_LEN) != 0) return -1.0f;

    // 응답 태그 주소 확인 (bytes 18-19) — 다른 태그 응답이면 무시
    if (frame_len >= 20) {
        uint16_t respAddr = ((uint16_t)rx_buffer[RESP_MSG_RESP_ADDR_IDX] << 8)
                           | rx_buffer[RESP_MSG_RESP_ADDR_IDX + 1];
        if (respAddr != 0 && respAddr != targetAddr) return -1.0f;
    }

    // 거리 계산 (SS-TWR)
    uint32_t poll_tx_ts = dwt_readtxtimestamplo32();
    uint32_t resp_rx_ts = dwt_readrxtimestamplo32();
    float clockOffsetRatio = ((float)dwt_readclockoffset()) / (uint32_t)(1 << 26);

    uint32_t poll_rx_ts, resp_tx_ts;
    resp_msg_get_ts(&rx_buffer[RESP_MSG_POLL_RX_TS_IDX], &poll_rx_ts);
    resp_msg_get_ts(&rx_buffer[RESP_MSG_RESP_TX_TS_IDX], &resp_tx_ts);

    int32_t rtd_init = (int32_t)(resp_rx_ts - poll_tx_ts);
    int32_t rtd_resp = (int32_t)(resp_tx_ts - poll_rx_ts);
    double tof = ((rtd_init - rtd_resp * (1.0 - clockOffsetRatio)) / 2.0) * DWT_TIME_UNITS;
    float dist  = (float)(tof * SPEED_OF_LIGHT);

    // 물리적으로 불가능한 값 필터링
    return (dist > 0.0f && dist < 100.0f) ? dist : -1.0f;
}

// ─── 안전 상태 머신 ─────────────────────────────────────────────────
bool anyRelayRequired() {
    for (int i = 0; i < TAG_SLOT_COUNT; i++)
        if (tagStates[i].relay || tagStates[i].fault) return true;
    return false;
}

void updateSafetyState(int idx, float distM) {
    TagState& ts = tagStates[idx];
    ts.lastDist    = distM;
    ts.lastRangeMs = millis();
    ts.fault       = false;
    ts.seq++;

    if (distM <= DANGER_DIST_M) {
        ts.dangerLatched = true;
        ts.safeCount     = 0;
        ts.relay         = true;
    } else if (distM >= SAFE_DIST_M) {
        if (ts.dangerLatched) {
            ts.safeCount++;
            if (ts.safeCount >= SAFE_COUNT_REQ) {
                ts.dangerLatched = false;
                ts.relay         = false;
                ts.safeCount     = 0;
            }
        }
    }
    // 3.0–3.5m 히스테리시스: 이전 상태 유지

    digitalWrite(RELAY_PIN, anyRelayRequired() ? HIGH : LOW);

    Serial.printf("{\"anchor\":\"%s\",\"tag\":\"%s\",\"dist\":%.3f,\"relay\":%s,\"zone\":\"%s\"}\n",
        ANCHOR_ID, TAG_IDS[idx], distM,
        anyRelayRequired() ? "true" : "false",
        ts.dangerLatched ? "DANGER" : (distM < SAFE_DIST_M ? "CAUTION" : "SAFE"));
}

void checkFaults() {
    unsigned long now = millis();
    for (int i = 0; i < TAG_SLOT_COUNT; i++) {
        if (tagStates[i].lastRangeMs > 0 &&
            (now - tagStates[i].lastRangeMs) > NO_RANGE_MS &&
            !tagStates[i].fault) {
            tagStates[i].fault = true;
            Serial.printf("{\"anchor\":\"%s\",\"tag\":\"%s\",\"event\":\"NO_RANGE_FAULT\"}\n",
                ANCHOR_ID, TAG_IDS[i]);
        }
    }
    digitalWrite(RELAY_PIN, anyRelayRequired() ? HIGH : LOW);
}

// ─── WiFi POST ──────────────────────────────────────────────────────
void postToServer(int idx, float distM) {
    if (WiFi.status() != WL_CONNECTED) return;

    TagState& ts  = tagStates[idx];
    const char* zone = ts.dangerLatched ? "DANGER" : (distM < SAFE_DIST_M ? "CAUTION" : "SAFE");

    StaticJsonDocument<256> doc;
    doc["anchorId"]  = ANCHOR_ID;
    doc["lat"]       = gpsValid ? anchorLat : 0.0;
    doc["lon"]       = gpsValid ? anchorLon : 0.0;
    doc["tagId"]     = TAG_IDS[idx];
    doc["distanceM"] = distM;
    doc["danger"]    = ts.dangerLatched;
    doc["relay"]     = ts.relay;
    doc["zone"]      = zone;
    doc["seq"]       = ts.seq;
    doc["uptimeMs"]  = (uint32_t)millis();

    String body;
    serializeJson(doc, body);

    HTTPClient http;
    http.begin(SERVER_URL);
    http.addHeader("Content-Type", "application/json");
    http.POST(body);
    http.end();
}

// ─── setup / loop ───────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(500);

    pinMode(RELAY_PIN, OUTPUT);
    digitalWrite(RELAY_PIN, LOW);

    // GPS 모듈 연결 시 아래 주석 해제
    // gpsSerial.begin(GPS_BAUD, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);

    dw3000_hw_init();

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.print("WiFi 연결 중");
    for (int i = 0; i < 20 && WiFi.status() != WL_CONNECTED; i++) {
        delay(500); Serial.print('.');
    }
    Serial.println(WiFi.status() == WL_CONNECTED ? " 완료" : " 실패(오프라인 모드)");
    Serial.printf("앵커 %s 측정 시작\n", ANCHOR_ID);
}

void loop() {
    // GPS NMEA 파싱 (GPS 모듈 연결 시 주석 해제)
    // while (gpsSerial.available()) {
    //     if (gps.encode(gpsSerial.read()) && gps.location.isValid()) {
    //         anchorLat = gps.location.lat();
    //         anchorLon = gps.location.lng();
    //         gpsValid  = true;
    //     }
    // }

    // TDMA: 각 태그 순서대로 SS-TWR 측정 (안전 로직은 즉시 적용)
    float distances[TAG_SLOT_COUNT];
    for (int slot = 0; slot < TAG_SLOT_COUNT; slot++) {
        distances[slot] = dw3000_measure_distance(TAG_ADDRS[slot]);
        if (distances[slot] >= 0.0f) {
            updateSafetyState(slot, distances[slot]); // 릴레이 즉시 제어
        }
        delay(INTER_SLOT_MS); // 태그가 다음 슬롯을 위해 RX 모드로 복귀할 시간
    }

    // WiFi POST (안전 로직과 분리 — 네트워크 지연이 릴레이에 영향 없음)
    for (int slot = 0; slot < TAG_SLOT_COUNT; slot++) {
        if (distances[slot] >= 0.0f) {
            postToServer(slot, distances[slot]);
        }
    }

    checkFaults();
}
