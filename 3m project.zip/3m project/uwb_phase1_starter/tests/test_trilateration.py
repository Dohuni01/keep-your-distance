import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))
from trilateration import trilaterate
import math

def test_basic_trilateration():
    anchors = [(0.0, 0.0), (10.0, 0.0), (0.0, 10.0)]
    distances = [5.0, math.sqrt(65), math.sqrt(45)]
    result = trilaterate(anchors, distances)
    assert result is not None
    x, y = result
    assert abs(x - 3.0) < 0.01
    assert abs(y - 4.0) < 0.01

def test_trilaterate_returns_none_with_two_anchors():
    anchors = [(0.0, 0.0), (10.0, 0.0)]
    distances = [5.0, 8.06]
    result = trilaterate(anchors, distances)
    assert result is None

def test_trilaterate_with_noise():
    anchors = [(0.0, 0.0), (10.0, 0.0), (0.0, 10.0)]
    distances = [5.1, math.sqrt(65) - 0.1, math.sqrt(45) + 0.05]
    result = trilaterate(anchors, distances)
    assert result is not None
    x, y = result
    assert abs(x - 3.0) < 0.5
    assert abs(y - 4.0) < 0.5
