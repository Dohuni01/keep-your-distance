import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))
from gps_utils import latlon_to_xy, xy_to_latlon, latlon_to_pixel

# 서울 근처 기준점
ORIGIN_LAT = 37.5
ORIGIN_LON = 127.0


def test_latlon_to_xy_origin():
    x, y = latlon_to_xy(ORIGIN_LAT, ORIGIN_LON, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x) < 0.01
    assert abs(y) < 0.01


def test_latlon_to_xy_north_10m():
    """북쪽으로 약 10m = 위도 약 0.0000899도"""
    delta = 10.0 / 111320.0
    x, y = latlon_to_xy(ORIGIN_LAT + delta, ORIGIN_LON, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x) < 0.1
    assert abs(y - 10.0) < 0.1


def test_latlon_to_xy_east_10m():
    """동쪽으로 약 10m"""
    import math
    cos_lat = math.cos(math.radians(ORIGIN_LAT))
    delta = 10.0 / (cos_lat * 111320.0)
    x, y = latlon_to_xy(ORIGIN_LAT, ORIGIN_LON + delta, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x - 10.0) < 0.1
    assert abs(y) < 0.1


def test_xy_to_latlon_roundtrip():
    x, y = 30.0, 20.0
    lat, lon = xy_to_latlon(x, y, ORIGIN_LAT, ORIGIN_LON)
    x2, y2 = latlon_to_xy(lat, lon, ORIGIN_LAT, ORIGIN_LON)
    assert abs(x2 - x) < 0.001
    assert abs(y2 - y) < 0.001


def test_latlon_to_pixel_top_left():
    bounds = {'top_left': (37.51, 127.00), 'bot_right': (37.50, 127.01)}
    px, py = latlon_to_pixel(37.51, 127.00, bounds, 1000, 500)
    assert abs(px) < 1.0
    assert abs(py) < 1.0


def test_latlon_to_pixel_bottom_right():
    bounds = {'top_left': (37.51, 127.00), 'bot_right': (37.50, 127.01)}
    px, py = latlon_to_pixel(37.50, 127.01, bounds, 1000, 500)
    assert abs(px - 1000) < 1.0
    assert abs(py - 500) < 1.0


def test_latlon_to_pixel_center():
    bounds = {'top_left': (37.51, 127.00), 'bot_right': (37.50, 127.01)}
    px, py = latlon_to_pixel(37.505, 127.005, bounds, 1000, 500)
    assert abs(px - 500) < 1.0
    assert abs(py - 250) < 1.0
