/*
  UWB Phase 1 - Worker Tag / Responder Template

  Use your DW3000 board manufacturer's DS-TWR responder example as the base.
  This file documents what must be changed per tag.

  Required per tag:
    TAG-001: short address 0x1001
    TAG-002: short address 0x1002
    TAG-003: short address 0x1003
    TAG-004: short address 0x1004

  Responder behavior:
    - Stay in RX / responder mode
    - When equipment node 0xE001 sends a poll, reply according to DS-TWR protocol
    - Do NOT control relay on worker tag during phase 1
    - Optional: blink LED when ranging request is received

  Integration point example, pseudo-code only:

  #include <Your_DW3000_Library.h>

  const uint16_t MY_TAG_ID = 0x1001;    // change per tag
  const uint16_t EQUIPMENT_ID = 0xE001;

  void setup() {
    Serial.begin(115200);
    dw3000.begin(...);
    dw3000.setShortAddress(MY_TAG_ID);
    dw3000.setNetworkId(0xBEEF);
    dw3000.startResponder();
  }

  void loop() {
    dw3000.responderLoop();
  }
*/

void setup() {
  // Replace this template with the board manufacturer's DW3000 DS-TWR responder example.
}

void loop() {
  // Responder loop from the DW3000 example.
}
