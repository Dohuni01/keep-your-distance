"""
UWB + GPS 실시간 위치 추적 서버.

앵커에서 POST /range 로 GPS+거리 데이터 수신 → 삼변측량 → SSE로 브라우저 push.
"""

import json
import os
import threading
import time
from queue import Queue, Empty

from flask import Flask, Response, jsonify, request, send_from_directory

from gps_utils import latlon_to_xy, xy_to_latlon, latlon_to_pixel
from trilateration import trilaterate

app = Flask(__name__, static_folder='static')

# --- 공유 상태 (Lock 보호) ---
_lock = threading.Lock()

# 최신 앵커 데이터: { anchorId -> {lat, lon, tagId -> distanceM} }
_anchor_data = {}

# 태그별 최신 위치+상태: { tagId -> {lat, lon, px, py, danger, distances, ts} }
_tag_states = {}

# SSE 구독자 큐 목록
_subscribers = []

# 지도 설정: GPS 바운드 + 이미지 크기
_map_config = {
    'bounds': {
        'top_left': (37.51, 127.00),
        'bot_right': (37.50, 127.01),
    },
    'img_width': 800,
    'img_height': 600,
}

# 지도 이미지 파일 경로 (업로드 시 갱신)
_map_image_path = None


# --- SSE 헬퍼 ---

def _push_event(data: dict):
    """모든 SSE 구독자에게 이벤트 전송."""
    msg = f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
    dead = []
    with _lock:
        for q in _subscribers:
            try:
                q.put_nowait(msg)
            except Exception:
                dead.append(q)
        for q in dead:
            _subscribers.remove(q)


# --- 삼변측량 트리거 ---

def _recalculate_tag(tag_id: str):
    """tag_id 에 대한 삼변측량을 수행하고 _tag_states 를 갱신."""
    anchors_xy = []
    distances = []
    origin = None

    with _lock:
        for anchor_id, anchor_info in _anchor_data.items():
            if tag_id not in anchor_info.get('tags', {}):
                continue
            lat = anchor_info.get('lat')
            lon = anchor_info.get('lon')
            dist = anchor_info['tags'][tag_id]
            if lat is None or lon is None:
                continue
            if origin is None:
                origin = (lat, lon)
            anchors_xy.append(latlon_to_xy(lat, lon, origin[0], origin[1]))
            distances.append(dist)

        bounds = _map_config['bounds']
        img_w = _map_config['img_width']
        img_h = _map_config['img_height']

    if len(anchors_xy) < 3:
        return  # 앵커 3개 미만이면 위치 계산 생략

    pos = trilaterate(anchors_xy, distances)
    if pos is None:
        return

    x, y = pos
    tag_lat, tag_lon = xy_to_latlon(x, y, origin[0], origin[1])
    px, py = latlon_to_pixel(tag_lat, tag_lon, bounds, img_w, img_h)

    min_dist = min(distances)
    danger = min_dist <= 3.0

    with _lock:
        _tag_states[tag_id] = {
            'tagId': tag_id,
            'lat': tag_lat,
            'lon': tag_lon,
            'px': px,
            'py': py,
            'danger': danger,
            'minDist': min_dist,
            'distances': {aid: _anchor_data[aid]['tags'].get(tag_id)
                          for aid in _anchor_data
                          if tag_id in _anchor_data[aid].get('tags', {})},
            'ts': time.time(),
        }

    _push_event({'type': 'tag_position', 'tag': _tag_states[tag_id]})


# --- 앵커 위치 픽셀 변환 ---

def _anchor_pixel(lat, lon):
    with _lock:
        bounds = _map_config['bounds']
        img_w = _map_config['img_width']
        img_h = _map_config['img_height']
    return latlon_to_pixel(lat, lon, bounds, img_w, img_h)


# --- 엔드포인트 ---

@app.route('/range', methods=['POST'])
def post_range():
    """앵커 → 서버: GPS+거리 데이터 수신.

    Body JSON:
    {
        "anchorId": "ANC-001",
        "lat": 37.505,
        "lon": 127.005,
        "tagId": "TAG-001",
        "distanceM": 2.35,
        "danger": true,
        "relay": true,
        "zone": "DANGER",
        "seq": 42,
        "uptimeMs": 123456
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({'error': 'invalid json'}), 400

    anchor_id = data.get('anchorId')
    tag_id = data.get('tagId')
    dist = data.get('distanceM')
    lat = data.get('lat')
    lon = data.get('lon')

    if not anchor_id or not tag_id or dist is None:
        return jsonify({'error': 'missing fields'}), 400

    with _lock:
        if anchor_id not in _anchor_data:
            _anchor_data[anchor_id] = {'lat': None, 'lon': None, 'tags': {}}
        if lat is not None:
            _anchor_data[anchor_id]['lat'] = lat
            _anchor_data[anchor_id]['lon'] = lon
        _anchor_data[anchor_id]['tags'][tag_id] = dist

    # 앵커 위치 이벤트 push
    if lat is not None:
        px, py = _anchor_pixel(lat, lon)
        _push_event({
            'type': 'anchor_position',
            'anchorId': anchor_id,
            'lat': lat, 'lon': lon,
            'px': px, 'py': py,
        })

    # 릴레이/위험 이벤트 즉시 push
    if data.get('danger'):
        _push_event({
            'type': 'danger',
            'anchorId': anchor_id,
            'tagId': tag_id,
            'distanceM': dist,
            'zone': data.get('zone', 'DANGER'),
        })

    # 삼변측량 (스레드에서 비동기 실행 — 메인 응답 지연 방지)
    threading.Thread(target=_recalculate_tag, args=(tag_id,), daemon=True).start()

    return jsonify({'status': 'ok'})


@app.route('/events')
def sse_events():
    """SSE 스트림 — 브라우저가 구독."""
    q = Queue(maxsize=100)
    with _lock:
        _subscribers.append(q)

    def generate():
        # 연결 즉시 현재 상태 전송
        with _lock:
            current_tags = list(_tag_states.values())
            current_anchors = [
                {
                    'anchorId': aid,
                    'lat': info.get('lat'),
                    'lon': info.get('lon'),
                }
                for aid, info in _anchor_data.items()
                if info.get('lat') is not None
            ]
        yield f"data: {json.dumps({'type': 'init', 'tags': current_tags, 'anchors': current_anchors})}\n\n"

        try:
            while True:
                try:
                    msg = q.get(timeout=25)
                    yield msg
                except Empty:
                    yield ': heartbeat\n\n'
        except GeneratorExit:
            with _lock:
                try:
                    _subscribers.remove(q)
                except ValueError:
                    pass

    return Response(generate(), mimetype='text/event-stream',
                    headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


@app.route('/state')
def get_state():
    """현재 전체 상태 스냅샷 (디버그용)."""
    with _lock:
        return jsonify({
            'anchors': _anchor_data,
            'tags': _tag_states,
            'mapConfig': _map_config,
        })


@app.route('/config/bounds', methods=['POST'])
def set_bounds():
    """지도 GPS 바운드 + 이미지 크기 설정.

    Body JSON:
    {
        "top_left": [37.51, 127.00],
        "bot_right": [37.50, 127.01],
        "img_width": 800,
        "img_height": 600
    }
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({'error': 'invalid json'}), 400

    with _lock:
        if 'top_left' in data:
            _map_config['bounds']['top_left'] = tuple(data['top_left'])
        if 'bot_right' in data:
            _map_config['bounds']['bot_right'] = tuple(data['bot_right'])
        if 'img_width' in data:
            _map_config['img_width'] = int(data['img_width'])
        if 'img_height' in data:
            _map_config['img_height'] = int(data['img_height'])

    _push_event({'type': 'config', 'mapConfig': _map_config})
    return jsonify({'status': 'ok', 'mapConfig': _map_config})


@app.route('/config/map', methods=['POST'])
def upload_map():
    """지도 이미지 파일 업로드."""
    global _map_image_path
    if 'file' not in request.files:
        return jsonify({'error': 'no file'}), 400

    f = request.files['file']
    save_dir = os.path.join(os.path.dirname(__file__), 'static')
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, 'map.jpg')
    f.save(save_path)
    _map_image_path = 'map.jpg'

    _push_event({'type': 'map_updated', 'url': '/static/map.jpg'})
    return jsonify({'status': 'ok', 'url': '/static/map.jpg'})


@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'static'), filename)


@app.route('/dashboard')
@app.route('/')
def dashboard():
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'static'), 'index.html')


if __name__ == '__main__':
    print("서버 시작: http://localhost:5000/dashboard")
    app.run(host='0.0.0.0', port=5000, threaded=True)
