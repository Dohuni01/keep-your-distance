import math

METERS_PER_DEGREE_LAT = 111320.0


def latlon_to_xy(lat, lon, origin_lat, origin_lon):
    """GPS 좌표를 원점 기준 미터 단위 로컬 XY로 변환."""
    cos_lat = math.cos(math.radians(origin_lat))
    dx = (lon - origin_lon) * cos_lat * METERS_PER_DEGREE_LAT
    dy = (lat - origin_lat) * METERS_PER_DEGREE_LAT
    return dx, dy


def xy_to_latlon(x, y, origin_lat, origin_lon):
    """로컬 XY(미터)를 GPS 좌표로 역변환."""
    cos_lat = math.cos(math.radians(origin_lat))
    lat = origin_lat + y / METERS_PER_DEGREE_LAT
    lon = origin_lon + x / (cos_lat * METERS_PER_DEGREE_LAT)
    return lat, lon


def latlon_to_pixel(lat, lon, bounds, img_width, img_height):
    """GPS 좌표를 지도 이미지 픽셀 좌표로 변환.

    bounds = {'top_left': (lat0, lon0), 'bot_right': (lat1, lon1)}
    """
    lat0, lon0 = bounds['top_left']
    lat1, lon1 = bounds['bot_right']
    px = (lon - lon0) / (lon1 - lon0) * img_width
    py = (lat0 - lat) / (lat0 - lat1) * img_height
    return px, py
