'use strict';

// --- 상태 ---
const state = {
  tags: {},      // tagId -> {tagId, px, py, danger, minDist, ...}
  anchors: {},   // anchorId -> {anchorId, lat, lon, px, py}
  mapImg: null,
  mapConfig: {
    bounds: { top_left: [37.51, 127.00], bot_right: [37.50, 127.01] },
    img_width: 800,
    img_height: 600,
  },
  dangerActive: false,
};

// --- Canvas ---
const canvas = document.getElementById('map-canvas');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
  const area = document.getElementById('map-area');
  canvas.width = area.clientWidth;
  canvas.height = area.clientHeight;
  draw();
}

window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// --- GPS→픽셀 변환 ---
function gpsToCanvas(px_norm, py_norm) {
  // px_norm, py_norm: 지도 이미지 기준 픽셀 (0~img_width, 0~img_height)
  // Canvas 크기에 맞게 스케일
  const cfg = state.mapConfig;
  const scaleX = canvas.width / cfg.img_width;
  const scaleY = canvas.height / cfg.img_height;
  return [px_norm * scaleX, py_norm * scaleY];
}

// 3m가 픽셀 몇 개인지 계산 (위도 기준 근사)
function metersToPixels(meters) {
  const cfg = state.mapConfig;
  const [lat0, lon0] = cfg.bounds.top_left;
  const [lat1, lon1] = cfg.bounds.bot_right;
  const latSpanM = Math.abs(lat0 - lat1) * 111320;
  const scaleY = canvas.height / latSpanM;
  return meters * scaleY;
}

// --- 그리기 ---
const TAG_COLORS = ['#3fb950', '#f0883e', '#d2a8ff', '#79c0ff', '#ffa657'];

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // 배경 지도 이미지
  if (state.mapImg) {
    ctx.drawImage(state.mapImg, 0, 0, canvas.width, canvas.height);
  } else {
    ctx.fillStyle = '#0d1117';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#21262d';
    ctx.font = '14px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText('지도 이미지를 업로드하세요', canvas.width / 2, canvas.height / 2);
  }

  // 앵커 — 파란 사각형 + 3m 위험 반경
  const r3m = metersToPixels(3.0);
  for (const a of Object.values(state.anchors)) {
    const [cx, cy] = gpsToCanvas(a.px, a.py);

    // 3m 위험 반경 (점선)
    ctx.save();
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = 'rgba(248, 81, 73, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, r3m, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // 앵커 사각형
    ctx.fillStyle = '#58a6ff';
    ctx.fillRect(cx - 8, cy - 8, 16, 16);
    ctx.fillStyle = '#e6edf3';
    ctx.font = '10px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText(a.anchorId.replace('ANC-', 'A'), cx, cy + 20);
  }

  // 태그 — 색깔 원
  let tagIdx = 0;
  for (const t of Object.values(state.tags)) {
    const color = TAG_COLORS[tagIdx % TAG_COLORS.length];
    tagIdx++;
    const [cx, cy] = gpsToCanvas(t.px, t.py);

    // 위험 시 빨간 후광
    if (t.danger) {
      ctx.save();
      ctx.shadowColor = '#f85149';
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(cx, cy, 12, 0, Math.PI * 2);
      ctx.fillStyle = '#f85149';
      ctx.fill();
      ctx.restore();
    }

    ctx.beginPath();
    ctx.arc(cx, cy, 10, 0, Math.PI * 2);
    ctx.fillStyle = t.danger ? '#f85149' : color;
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 9px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText(t.tagId.replace('TAG-', 'T'), cx, cy + 4);

    // 거리 라벨
    ctx.fillStyle = '#e6edf3';
    ctx.font = '10px Segoe UI';
    ctx.fillText(`${t.minDist != null ? t.minDist.toFixed(2) + 'm' : ''}`, cx, cy + 22);
  }
}

// --- 사이드바 업데이트 ---
function updateSidebar() {
  const tagList = document.getElementById('tag-list');
  const tags = Object.values(state.tags);

  if (tags.length === 0) {
    tagList.innerHTML = '<p style="font-size:12px;color:#484f58">수신 대기 중...</p>';
  } else {
    tagList.innerHTML = tags.map((t, i) => {
      const color = TAG_COLORS[i % TAG_COLORS.length];
      const dist = t.minDist != null ? t.minDist.toFixed(2) + 'm' : '--';
      const zone = t.danger ? '⚠ DANGER' : 'SAFE';
      return `<div class="tag-card ${t.danger ? 'danger' : ''}">
        <h3 style="color:${color}">${t.tagId}</h3>
        <div class="dist">${dist}</div>
        <div class="zone">${zone}</div>
      </div>`;
    }).join('');
  }

  const anchorList = document.getElementById('anchor-list');
  const anchors = Object.values(state.anchors);
  if (anchors.length === 0) {
    anchorList.innerHTML = '';
  } else {
    anchorList.innerHTML = anchors.map(a =>
      `<div class="anchor-card"><span>${a.anchorId}</span><br>
      ${a.lat != null ? a.lat.toFixed(6) + ', ' + a.lon.toFixed(6) : '위치 미수신'}</div>`
    ).join('');
  }

  // 상태바
  const anyDanger = tags.some(t => t.danger);
  state.dangerActive = anyDanger;
  document.getElementById('danger-overlay').classList.toggle('active', anyDanger);
  document.getElementById('relay-status').textContent = `릴레이: ${anyDanger ? '🔴 ON' : '🟢 OFF'}`;
  document.getElementById('tag-count').textContent = `태그: ${tags.length}개`;
  document.getElementById('anchor-count').textContent = `앵커: ${anchors.length}개`;
}

// --- SSE 연결 ---
let sse = null;

function connectSSE() {
  sse = new EventSource('/events');
  document.getElementById('conn-status').textContent = '● 연결 중...';
  document.getElementById('conn-status').style.color = '#f0883e';

  sse.onopen = () => {
    document.getElementById('conn-status').textContent = '● 연결됨';
    document.getElementById('conn-status').style.color = '#3fb950';
  };

  sse.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    handleEvent(msg);
  };

  sse.onerror = () => {
    document.getElementById('conn-status').textContent = '● 연결 끊김 — 재시도 중';
    document.getElementById('conn-status').style.color = '#f85149';
    sse.close();
    setTimeout(connectSSE, 3000);
  };
}

function handleEvent(msg) {
  switch (msg.type) {
    case 'init':
      for (const t of (msg.tags || [])) state.tags[t.tagId] = t;
      for (const a of (msg.anchors || [])) state.anchors[a.anchorId] = a;
      break;

    case 'tag_position':
      state.tags[msg.tag.tagId] = msg.tag;
      break;

    case 'anchor_position':
      state.anchors[msg.anchorId] = msg;
      break;

    case 'danger':
      // 이미 tag_position 이벤트로 처리됨; 추가 알림 필요 시 여기서 처리
      break;

    case 'config':
      state.mapConfig = msg.mapConfig;
      break;

    case 'map_updated':
      loadMapImage(msg.url);
      break;
  }
  draw();
  updateSidebar();
}

// --- 지도 이미지 로드 ---
function loadMapImage(url) {
  const img = new Image();
  img.onload = () => { state.mapImg = img; draw(); };
  img.src = url + '?t=' + Date.now(); // 캐시 무효화
}

// --- 설정 적용 ---
function applyBounds() {
  const tlLat = parseFloat(document.getElementById('tl-lat').value);
  const tlLon = parseFloat(document.getElementById('tl-lon').value);
  const brLat = parseFloat(document.getElementById('br-lat').value);
  const brLon = parseFloat(document.getElementById('br-lon').value);

  if ([tlLat, tlLon, brLat, brLon].some(isNaN)) {
    alert('GPS 좌표를 올바르게 입력하세요.');
    return;
  }

  fetch('/config/bounds', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      top_left: [tlLat, tlLon],
      bot_right: [brLat, brLon],
      img_width: state.mapConfig.img_width,
      img_height: state.mapConfig.img_height,
    }),
  }).then(r => r.json()).then(d => {
    state.mapConfig = d.mapConfig;
    draw();
  });
}

// --- 지도 이미지 업로드 ---
function uploadMap(input) {
  if (!input.files[0]) return;
  const formData = new FormData();
  formData.append('file', input.files[0]);

  // 업로드 전에 이미지 크기를 읽어서 mapConfig 갱신
  const reader = new FileReader();
  const img = new Image();
  img.onload = () => {
    state.mapConfig.img_width = img.naturalWidth;
    state.mapConfig.img_height = img.naturalHeight;
    fetch('/config/map', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(d => loadMapImage(d.url));
  };
  reader.onload = e => { img.src = e.target.result; };
  reader.readAsDataURL(input.files[0]);
}

// --- 시작 ---
connectSSE();
