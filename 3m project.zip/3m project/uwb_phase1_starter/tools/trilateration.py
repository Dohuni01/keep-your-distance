import numpy as np


def trilaterate(anchors, distances):
    """3개 이상의 앵커 좌표와 거리로 태그 위치(x, y)를 최소제곱법으로 계산."""
    if len(anchors) < 3 or len(distances) < 3:
        return None

    x1, y1 = anchors[0]
    d1 = distances[0]

    rows_A = []
    rows_b = []
    for i in range(1, len(anchors)):
        xi, yi = anchors[i]
        di = distances[i]
        rows_A.append([2 * (xi - x1), 2 * (yi - y1)])
        rows_b.append(d1**2 - di**2 + xi**2 - x1**2 + yi**2 - y1**2)

    A = np.array(rows_A, dtype=float)
    b = np.array(rows_b, dtype=float)

    try:
        result, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        return float(result[0]), float(result[1])
    except np.linalg.LinAlgError:
        return None
