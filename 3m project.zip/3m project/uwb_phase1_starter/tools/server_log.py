#!/usr/bin/env python3
"""
Simple HTTP JSON logger for UWB Phase 1 tests.
No external packages required.

Run:
  python3 server_log.py --host 0.0.0.0 --port 8000

Then set equipment_node.ino:
  USE_WIFI_POST 1
  SERVER_URL "http://<PC_IP>:8000/range"
"""

from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime
import argparse
import json
import csv
from pathlib import Path

CSV_PATH = Path("uwb_events.csv")

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8", errors="replace")
        now = datetime.now().isoformat(timespec="milliseconds")

        try:
            data = json.loads(body)
            print(now, json.dumps(data, ensure_ascii=False))
            write_csv(now, data)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")
        except Exception as e:
            print(now, "BAD_JSON", body, e)
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"BAD_JSON")

    def log_message(self, fmt, *args):
        return


def write_csv(received_at, data):
    exists = CSV_PATH.exists()
    fields = [
        "receivedAt", "equipmentId", "tagId", "event", "seq", "distanceM",
        "danger", "relay", "noRange", "fault", "zone", "uptimeMs"
    ]
    with CSV_PATH.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            writer.writeheader()
        row = {field: data.get(field, "") for field in fields}
        row["receivedAt"] = received_at
        writer.writerow(row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server = HTTPServer((args.host, args.port), Handler)
    print(f"Listening on http://{args.host}:{args.port}/range")
    print(f"CSV log: {CSV_PATH.resolve()}")
    server.serve_forever()

if __name__ == "__main__":
    main()
