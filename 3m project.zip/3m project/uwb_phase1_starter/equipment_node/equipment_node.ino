/*
  UWB Phase 1 - Equipment Node / Excavator Node
  Target: ESP32 + DW3000 UWB board

  What this code does:
  - Keeps 4 worker tag states
  - Latches DANGER immediately when distance <= 3.0 m
  - Releases only when distance >= 3.5 m is observed 3 times in a row
  - Treats No Range near the danger zone as FAULT, not SAFE
  - Controls a relay locally
  - Prints JSON logs to Serial
  - Optional HTTP POST to a local server

  IMPORTANT:
  The DW3000 ranging API differs by board/library.
  Connect your board manufacturer's DS-TWR initiator/ranger example to the hook functions below:
    - onUwbRange(tagId, distanceM, rssi)
    - onUwbNoRange(tagId)

  For bench-testing only the relay/state machine without UWB, set USE_FAKE_SERIAL_RANGES = 1
  and type lines into Serial Monitor like:
    1001 2.75
    1001 3.80
    1002 NR
*/

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>

// ======================== USER CONFIG ========================
#define USE_WIFI_POST 0
#define USE_FAKE_SERIAL_RANGES 1   // 1: test by Serial input, 0: use real DW3000 ranging hooks

const char* WIFI_SSID = "후니";
const char* WIFI_PASS = "12345678*";
const char* SERVER_URL = "http://192.168.0.10:8000/range";

static const char* EQUIPMENT_ID = "EXC-001";

// Adjust these pins for your ESP32 UWB board and relay module.
static const int RELAY_PIN = 26;
static const bool RELAY_ACTIVE_LOW = false;  // many relay boards are active-low; set true if needed
static const int STATUS_LED_PIN = 2;

// 4 worker tags. Change IDs to match your UWB short address / tag ID scheme.
static const uint16_t TAG_IDS[] = {0x1001, 0x1002, 0x1003, 0x1004};
static const size_t TAG_COUNT = sizeof(TAG_IDS) / sizeof(TAG_IDS[0]);

// Danger policy
static const float DANGER_ON_M = 3.00f;
static const float DANGER_OFF_M = 3.50f;
static const uint8_t SAFE_SAMPLE_COUNT_TO_OFF = 3;

// No Range policy
static const uint32_t NO_RANGE_HOLD_MS = 1500;     // if last near/danger and ranging is lost, keep state and mark fault after this
static const uint32_t TAG_STALE_MS = 5000;         // no update longer than this means stale/offline
static const bool RELAY_ON_WHILE_FAULT = true;     // recommended for safety PoC; change after field discussion

// Reporting
static const uint32_t HEARTBEAT_MS = 1000;
// =============================================================

enum TagZone : uint8_t {
  ZONE_UNKNOWN = 0,
  ZONE_SAFE,
  ZONE_WARNING,
  ZONE_DANGER,
  ZONE_FAULT
};

struct TagState {
  uint16_t id;
  bool hasDistance;
  float lastDistanceM;
  int16_t lastRssi;
  uint32_t lastSeenMs;
  uint32_t lastNoRangeMs;
  bool dangerLatched;
  bool noRange;
  bool fault;
  uint8_t safeCount;
  uint32_t seq;
};

TagState tags[TAG_COUNT];
bool relayOn = false;
uint32_t lastHeartbeatMs = 0;
uint32_t bootMs = 0;

String tagIdHex(uint16_t id) {
  char buf[8];
  snprintf(buf, sizeof(buf), "%04X", id);
  return String(buf);
}

int findTagIndex(uint16_t id) {
  for (size_t i = 0; i < TAG_COUNT; i++) {
    if (tags[i].id == id) return (int)i;
  }
  return -1;
}

void writeRelay(bool on) {
  relayOn = on;
  bool level = RELAY_ACTIVE_LOW ? !on : on;
  digitalWrite(RELAY_PIN, level ? HIGH : LOW);
  digitalWrite(STATUS_LED_PIN, on ? HIGH : LOW);
}

bool tagRequiresRelay(const TagState& t) {
  if (t.dangerLatched) return true;
  if (RELAY_ON_WHILE_FAULT && t.fault) return true;
  return false;
}

bool systemRequiresRelay() {
  for (size_t i = 0; i < TAG_COUNT; i++) {
    if (tagRequiresRelay(tags[i])) return true;
  }
  return false;
}

const char* zoneName(const TagState& t) {
  if (t.fault) return "FAULT";
  if (t.dangerLatched) return "DANGER";
  if (!t.hasDistance) return "UNKNOWN";
  if (t.lastDistanceM < DANGER_OFF_M) return "WARNING";
  return "SAFE";
}

void printJsonEvent(const TagState& t, const char* eventType) {
  Serial.print('{');
  Serial.print("\"equipmentId\":\""); Serial.print(EQUIPMENT_ID); Serial.print("\",");
  Serial.print("\"tagId\":\""); Serial.print(tagIdHex(t.id)); Serial.print("\",");
  Serial.print("\"event\":\""); Serial.print(eventType); Serial.print("\",");
  Serial.print("\"seq\":"); Serial.print(t.seq); Serial.print(',');
  Serial.print("\"distanceM\":");
  if (t.hasDistance) Serial.print(t.lastDistanceM, 3); else Serial.print("null");
  Serial.print(',');
  Serial.print("\"danger\":"); Serial.print(t.dangerLatched ? "true" : "false"); Serial.print(',');
  Serial.print("\"relay\":"); Serial.print(relayOn ? "true" : "false"); Serial.print(',');
  Serial.print("\"noRange\":"); Serial.print(t.noRange ? "true" : "false"); Serial.print(',');
  Serial.print("\"fault\":"); Serial.print(t.fault ? "true" : "false"); Serial.print(',');
  Serial.print("\"zone\":\""); Serial.print(zoneName(t)); Serial.print("\",");
  Serial.print("\"rssi\":"); Serial.print(t.lastRssi); Serial.print(',');
  Serial.print("\"uptimeMs\":"); Serial.print(millis() - bootMs);
  Serial.println('}');
}

void postJsonState(const TagState& t, const char* eventType) {
#if USE_WIFI_POST
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");

  String payload = "{";
  payload += "\"equipmentId\":\"" + String(EQUIPMENT_ID) + "\",";
  payload += "\"tagId\":\"" + tagIdHex(t.id) + "\",";
  payload += "\"event\":\"" + String(eventType) + "\",";
  payload += "\"seq\":" + String(t.seq) + ",";
  payload += "\"distanceM\":" + String(t.hasDistance ? t.lastDistanceM : -1.0f, 3) + ",";
  payload += "\"danger\":" + String(t.dangerLatched ? "true" : "false") + ",";
  payload += "\"relay\":" + String(relayOn ? "true" : "false") + ",";
  payload += "\"noRange\":" + String(t.noRange ? "true" : "false") + ",";
  payload += "\"fault\":" + String(t.fault ? "true" : "false") + ",";
  payload += "\"zone\":\"" + String(zoneName(t)) + "\",";
  payload += "\"uptimeMs\":" + String(millis() - bootMs);
  payload += "}";

  int code = http.POST(payload);
  (void)code;
  http.end();
#else
  (void)t;
  (void)eventType;
#endif
}

void emitEvent(TagState& t, const char* eventType) {
  printJsonEvent(t, eventType);
  postJsonState(t, eventType);
}

void applyRelayAndEmitIfChanged(TagState& t, const char* eventType) {
  bool before = relayOn;
  bool required = systemRequiresRelay();
  if (required != before) {
    writeRelay(required);
  }
  emitEvent(t, eventType);
}

// Call this when a valid UWB range result is obtained.
void onUwbRange(uint16_t tagId, float distanceM, int16_t rssi = 0) {
  int idx = findTagIndex(tagId);
  if (idx < 0) return;

  TagState& t = tags[idx];
  t.seq++;
  t.hasDistance = true;
  t.lastDistanceM = distanceM;
  t.lastRssi = rssi;
  t.lastSeenMs = millis();
  t.noRange = false;

  bool wasDanger = t.dangerLatched;
  bool wasFault = t.fault;

  if (distanceM <= DANGER_ON_M) {
    t.dangerLatched = true;
    t.fault = false;
    t.safeCount = 0;
    applyRelayAndEmitIfChanged(t, wasDanger ? "DANGER_UPDATE" : "DANGER_ENTER");
    return;
  }

  if (distanceM >= DANGER_OFF_M) {
    if (t.dangerLatched || t.fault) {
      if (t.safeCount < 255) t.safeCount++;
      if (t.safeCount >= SAFE_SAMPLE_COUNT_TO_OFF) {
        t.dangerLatched = false;
        t.fault = false;
        t.safeCount = 0;
        applyRelayAndEmitIfChanged(t, (wasDanger || wasFault) ? "DANGER_EXIT" : "SAFE_UPDATE");
      } else {
        applyRelayAndEmitIfChanged(t, "SAFE_CANDIDATE");
      }
    } else {
      t.safeCount = 0;
      applyRelayAndEmitIfChanged(t, "SAFE_UPDATE");
    }
    return;
  }

  // Hysteresis zone: 3.0 m < distance < 3.5 m. Keep previous state.
  t.safeCount = 0;
  t.fault = false;
  applyRelayAndEmitIfChanged(t, t.dangerLatched ? "DANGER_HOLD" : "WARNING_UPDATE");
}

// Call this when a poll to a specific tag timed out / No Range occurred.
void onUwbNoRange(uint16_t tagId) {
  int idx = findTagIndex(tagId);
  if (idx < 0) return;

  TagState& t = tags[idx];
  t.seq++;
  t.noRange = true;
  t.lastNoRangeMs = millis();

  bool nearBeforeLoss = t.hasDistance && (t.lastDistanceM < DANGER_OFF_M);
  bool mustHold = t.dangerLatched || nearBeforeLoss;

  if (mustHold && (millis() - t.lastSeenMs >= NO_RANGE_HOLD_MS)) {
    t.fault = true;
    if (RELAY_ON_WHILE_FAULT) t.dangerLatched = true;
    applyRelayAndEmitIfChanged(t, "NO_RANGE_FAULT");
  } else {
    applyRelayAndEmitIfChanged(t, "NO_RANGE_HOLD");
  }
}

void checkStaleTags() {
  uint32_t now = millis();
  for (size_t i = 0; i < TAG_COUNT; i++) {
    TagState& t = tags[i];
    if (!t.hasDistance) continue;
    if (now - t.lastSeenMs > TAG_STALE_MS && !t.noRange) {
      t.noRange = true;
      t.seq++;
      emitEvent(t, "TAG_STALE");
    }
  }
}

void heartbeat() {
  uint32_t now = millis();
  if (now - lastHeartbeatMs < HEARTBEAT_MS) return;
  lastHeartbeatMs = now;

  Serial.print("{\"equipmentId\":\""); Serial.print(EQUIPMENT_ID);
  Serial.print("\",\"event\":\"HEARTBEAT\",\"relay\":"); Serial.print(relayOn ? "true" : "false");
  Serial.print(",\"tags\":[");
  for (size_t i = 0; i < TAG_COUNT; i++) {
    if (i) Serial.print(',');
    Serial.print('{');
    Serial.print("\"tagId\":\""); Serial.print(tagIdHex(tags[i].id)); Serial.print("\",");
    Serial.print("\"distanceM\":"); if (tags[i].hasDistance) Serial.print(tags[i].lastDistanceM, 3); else Serial.print("null"); Serial.print(',');
    Serial.print("\"zone\":\""); Serial.print(zoneName(tags[i])); Serial.print("\",");
    Serial.print("\"noRange\":"); Serial.print(tags[i].noRange ? "true" : "false"); Serial.print(',');
    Serial.print("\"fault\":"); Serial.print(tags[i].fault ? "true" : "false");
    Serial.print('}');
  }
  Serial.print("],\"uptimeMs\":"); Serial.print(now - bootMs);
  Serial.println('}');
}

void connectWifiIfNeeded() {
#if USE_WIFI_POST
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
    delay(250);
    Serial.print('.');
  }
  Serial.println();
  Serial.print("WiFi: ");
  Serial.println(WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : "not connected");
#endif
}

// ---------------- FAKE SERIAL RANGING ----------------
// Serial input examples:
//   1001 2.73
//   1001 NR
void pollFakeSerialRanges() {
#if USE_FAKE_SERIAL_RANGES
  static String line;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      line.trim();
      if (line.length() > 0) {
        char idBuf[16] = {0};
        char valBuf[16] = {0};
        int n = sscanf(line.c_str(), "%15s %15s", idBuf, valBuf);
        if (n >= 2) {
          uint16_t id = (uint16_t)strtol(idBuf, nullptr, 16); // hex input: 1001
          String val = String(valBuf);
          val.toUpperCase();
          if (val == "NR" || val == "NO" || val == "N") {
            onUwbNoRange(id);
          } else {
            float d = val.toFloat();
            onUwbRange(id, d, 0);
          }
        }
      }
      line = "";
    } else {
      line += c;
    }
  }
#endif
}

// ---------------- REAL DW3000 RANGING HOOK ----------------
void setupUwbReal() {
#if !USE_FAKE_SERIAL_RANGES
  // TODO:
  // 1) Initialize SPI + DW3000 using your board manufacturer's library.
  // 2) Configure this device as DS-TWR initiator / ranger.
  // 3) Set own short address, e.g. 0xE001.
  // 4) Use TAG_IDS[] as target short addresses.
  // 5) In the ranging-complete callback, call onUwbRange(targetId, distanceMeters, rssi).
  // 6) In timeout/no-response callback, call onUwbNoRange(targetId).
#endif
}

void pollUwbReal() {
#if !USE_FAKE_SERIAL_RANGES
  // TODO:
  // Poll tags sequentially to avoid collisions.
  // Example policy:
  //   every 80~150 ms, send one DS-TWR poll to TAG_IDS[currentTag]
  //   currentTag = (currentTag + 1) % TAG_COUNT
#endif
}

void setup() {
  bootMs = millis();
  Serial.begin(115200);
  delay(500);

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(STATUS_LED_PIN, OUTPUT);
  writeRelay(false);

  for (size_t i = 0; i < TAG_COUNT; i++) {
    tags[i].id = TAG_IDS[i];
    tags[i].hasDistance = false;
    tags[i].lastDistanceM = 999.0f;
    tags[i].lastRssi = 0;
    tags[i].lastSeenMs = 0;
    tags[i].lastNoRangeMs = 0;
    tags[i].dangerLatched = false;
    tags[i].noRange = false;
    tags[i].fault = false;
    tags[i].safeCount = 0;
    tags[i].seq = 0;
  }

  connectWifiIfNeeded();
  setupUwbReal();

  Serial.println("UWB Phase 1 Equipment Node started");
  Serial.println("Fake input examples: 1001 2.80 / 1001 3.80 / 1001 NR");
}

void loop() {
  pollFakeSerialRanges();
  pollUwbReal();
  checkStaleTags();
  heartbeat();
  delay(5);
}
