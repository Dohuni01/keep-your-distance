/**
 * tag_node.ino  —  UWB 태그 (Responder / 작업자 착용)
 * 대상: Makerfabs ESP32 UWB DW3000
 *
 * 라이브러리:
 *   https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000
 *   "Dw3000" 폴더를 Arduino/libraries/ 에 복사
 *
 * 태그마다 변경:
 *   MY_SHORT_ADDR (0x1001 / 0x1002)
 *   TAG_ID ("TAG-001" / "TAG-002")
 */

#include "dw3000.h"
#include <SPI.h>
#include <Arduino.h>

extern SPISettings _fastSPI;
extern dwt_txconfig_t txconfig_options;

// ─── 핀 (Makerfabs ESP32 UWB DW3000 고정) ──────────────────────────
#define PIN_RST  27
#define PIN_IRQ  34
#define PIN_SS    4

// ─── 태그 설정 (태그마다 변경) ──────────────────────────────────────
static const uint16_t MY_SHORT_ADDR = 0x1001;   // ← 0x1001 / 0x1002
static const char*    TAG_ID        = "TAG-001"; // ← MY_SHORT_ADDR 과 일치

// ─── DW3000 RF 파라미터 ─────────────────────────────────────────────
#define TX_ANT_DLY  16385
#define RX_ANT_DLY  16385

#define ALL_MSG_COMMON_LEN       10
#define ALL_MSG_SN_IDX            2
#define RESP_MSG_POLL_RX_TS_IDX  10
#define RESP_MSG_RESP_TX_TS_IDX  14
#define RESP_MSG_RESP_ADDR_IDX   18   // 응답 프레임의 내 주소 위치
#define POLL_RX_TO_RESP_TX_DLY_UUS  900

static dwt_config_t dw_config = {
    5,                /* Channel number */
    DWT_PLEN_128,     /* Preamble length */
    DWT_PAC8,
    9,                /* TX preamble code */
    9,                /* RX preamble code */
    1,
    DWT_BR_6M8,
    DWT_PHRMODE_STD,
    DWT_PHRRATE_STD,
    (129 + 8 - 8),
    DWT_STS_MODE_OFF,
    DWT_STS_LEN_64,
    DWT_PDOA_M0
};

// 수신 Poll 검증용 (첫 10바이트만 비교)
static uint8_t rx_poll_check[] = {
    0x41, 0x88, 0, 0xCA, 0xDE, 'W','A','V','E', 0xE0
};
// 송신 응답 프레임: bytes 18-19 = 내 주소
static uint8_t tx_resp_msg[] = {
    0x41, 0x88, 0, 0xCA, 0xDE, 'V','E','W','A', 0xE1,
    0, 0, 0, 0,   // bytes 10-13: poll_rx_ts
    0, 0, 0, 0,   // bytes 14-17: resp_tx_ts
    0, 0          // bytes 18-19: 내 주소 (setup()에서 삽입)
};

static uint8_t  rx_buffer[24];
static uint8_t  frame_seq_nb = 0;
static uint32_t status_reg   = 0;

// ─── DW3000 초기화 ──────────────────────────────────────────────────
void dw3000_hw_init() {
    _fastSPI = SPISettings(7000000L, MSBFIRST, SPI_MODE0);
    spiBegin(PIN_IRQ, PIN_RST);
    spiSelect(PIN_SS);
    delay(2);

    dwt_softreset();
    delay(2);

    if (!dwt_checkidlerc()) {
        Serial.println("[DW3000] IDLE FAILED — 배선 확인");
        while (1);
    }
    if (dwt_initialise(DWT_DW_INIT) == DWT_ERROR) {
        Serial.println("[DW3000] INIT FAILED");
        while (1);
    }

    dwt_setleds(DWT_LEDS_ENABLE | DWT_LEDS_INIT_BLINK);

    if (dwt_configure(&dw_config)) {
        Serial.println("[DW3000] CONFIG FAILED");
        while (1);
    }

    dwt_configuretxrf(&txconfig_options);
    dwt_setrxantennadelay(RX_ANT_DLY);
    dwt_settxantennadelay(TX_ANT_DLY);
    dwt_setlnapamode(DWT_LNA_ENABLE | DWT_PA_ENABLE);

    // 응답 프레임에 내 주소 미리 삽입 (변하지 않음)
    tx_resp_msg[RESP_MSG_RESP_ADDR_IDX]     = (uint8_t)(MY_SHORT_ADDR >> 8);
    tx_resp_msg[RESP_MSG_RESP_ADDR_IDX + 1] = (uint8_t)(MY_SHORT_ADDR & 0xFF);

    Serial.printf("[DW3000] 태그 0x%04X (%s) 초기화 완료\n", MY_SHORT_ADDR, TAG_ID);
}

// ─── setup / loop ───────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(500);
    dw3000_hw_init();
    Serial.printf("태그 %s — 앵커 Poll 대기 중\n", TAG_ID);
}

void loop() {
    // RX 활성화 — 앵커 Poll 대기
    dwt_rxenable(DWT_START_RX_IMMEDIATE);

    while (!((status_reg = dwt_read32bitreg(SYS_STATUS_ID)) &
             (SYS_STATUS_RXFCG_BIT_MASK | SYS_STATUS_ALL_RX_ERR)));

    if (!(status_reg & SYS_STATUS_RXFCG_BIT_MASK)) {
        dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_ALL_RX_ERR);
        return;
    }

    dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_RXFCG_BIT_MASK);
    uint32_t frame_len = dwt_read32bitreg(RX_FINFO_ID) & RXFLEN_MASK;

    if (frame_len > sizeof(rx_buffer)) return;
    dwt_readrxdata(rx_buffer, frame_len, 0);
    rx_buffer[ALL_MSG_SN_IDX] = 0;

    // Poll 프레임 시그니처 확인
    if (memcmp(rx_buffer, rx_poll_check, ALL_MSG_COMMON_LEN) != 0) return;

    // 내 주소로 온 Poll 인지 확인 (bytes 10-11)
    // targetAddr == 0 이면 브로드캐스트 (호환용)
    if (frame_len >= 12) {
        uint16_t targetAddr = ((uint16_t)rx_buffer[10] << 8) | rx_buffer[11];
        if (targetAddr != 0 && targetAddr != MY_SHORT_ADDR) return;
    }

    // Poll 수신 타임스탬프
    uint64_t poll_rx_ts   = get_rx_timestamp_u64();

    // 응답 전송 시간 계산 (900µs 후)
    uint32_t resp_tx_time = (poll_rx_ts + ((uint64_t)POLL_RX_TO_RESP_TX_DLY_UUS * UUS_TO_DWT_TIME)) >> 8;
    dwt_setdelayedtrxtime(resp_tx_time);
    uint64_t resp_tx_ts   = (((uint64_t)(resp_tx_time & 0xFFFFFFFEUL)) << 8) + TX_ANT_DLY;

    // 응답 프레임에 타임스탬프 삽입
    resp_msg_set_ts(&tx_resp_msg[RESP_MSG_POLL_RX_TS_IDX], poll_rx_ts);
    resp_msg_set_ts(&tx_resp_msg[RESP_MSG_RESP_TX_TS_IDX], resp_tx_ts);
    tx_resp_msg[ALL_MSG_SN_IDX] = frame_seq_nb;

    // 응답 전송
    dwt_writetxdata(sizeof(tx_resp_msg), tx_resp_msg, 0);
    dwt_writetxfctrl(sizeof(tx_resp_msg), 0, 1);
    int ret = dwt_starttx(DWT_START_TX_DELAYED);

    if (ret == DWT_SUCCESS) {
        while (!(dwt_read32bitreg(SYS_STATUS_ID) & SYS_STATUS_TXFRS_BIT_MASK));
        dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_TXFRS_BIT_MASK);
        frame_seq_nb++;
        Serial.printf("[TAG] 0x%04X → 앵커 응답 완료\n", MY_SHORT_ADDR);
    }
}
