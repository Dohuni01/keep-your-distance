# UWB Phase 1 Starter

Recommended first implementation with 5 UWB devices:

- 1 equipment node attached to excavator / dangerous equipment
- 4 worker tags
- Local relay control on the equipment node
- Server/logging is optional and must not be required for relay operation

The equipment firmware includes the complete danger state machine. The real DW3000 ranging code is intentionally isolated into two hook functions because library APIs differ by board vendor:

- `onUwbRange(tagId, distanceM, rssi)`
- `onUwbNoRange(tagId)`

Start by testing the state machine with fake serial ranges, then integrate the board manufacturer's DS-TWR initiator/responder examples.
