# UWB Phase 1 Test Plan - 5 Devices

## Device assignment

- 0xE001 / EXC-001: equipment node, relay attached
- 0x1001 / TAG-001: worker tag
- 0x1002 / TAG-002: worker tag
- 0x1003 / TAG-003: worker tag
- 0x1004 / TAG-004: worker tag

## Phase A - State machine without UWB

1. Flash `equipment_node.ino` with `USE_FAKE_SERIAL_RANGES = 1`.
2. Open Serial Monitor at 115200 baud.
3. Type:
   - `1001 4.00` -> SAFE, relay OFF
   - `1001 2.80` -> DANGER_ENTER, relay ON
   - `1001 3.20` -> DANGER_HOLD, relay ON
   - `1001 3.80` three times -> DANGER_EXIT, relay OFF
   - `1001 2.80`, wait, then `1001 NR` repeatedly -> NO_RANGE_FAULT, relay stays ON if configured

Pass condition:
- ON is immediate at <= 3.0 m.
- OFF occurs only after 3 consecutive safe samples at >= 3.5 m.
- No Range near danger is never treated as SAFE.

## Phase B - 1 equipment + 1 worker tag

1. Flash EXC-001 as DW3000 initiator/ranger.
2. Flash TAG-001 as DW3000 responder.
3. Use tape marks at 1 m, 2 m, 3 m, 3.5 m, 4 m, 5 m.
4. Collect at least 100 samples per distance.
5. Record mean, standard deviation, min, max, and P95 error.

Pass condition suggestion:
- At actual 2.8 m, relay turns ON consistently.
- At actual 3.7 m, relay stays OFF after hysteresis.
- Relay reaction time is logged and acceptable for demo target.

## Phase C - Calibration

For each distance point:
- actualM
- measuredMeanM
- bias = measuredMeanM - actualM

Initial correction:
- correctedM = measuredM - averageBias

If bias is not constant, create a simple lookup table.

## Phase D - Multi-tag polling

1. Enable TAG-001 ~ TAG-004.
2. Poll tags sequentially from EXC-001.
3. Check that each tag updates at least once per second.
4. Move only one tag inside 3 m; relay must turn ON and event must identify the correct tag.
5. Move all tags outside 3.5 m; relay must turn OFF after all danger/fault states are cleared.

## Phase E - Field/noise test

Test these conditions:
- Tag on chest, belt, arm, pocket.
- Human body between equipment and tag.
- Near metal, excavator bucket, steel plate, fence.
- Different antenna orientation: front/back/side.
- Wi-Fi/server disconnected: relay must still work locally.

Record:
- False ON cases outside 3.5 m.
- False OFF cases inside 3.0 m.
- No Range frequency.
- Relay delay.
